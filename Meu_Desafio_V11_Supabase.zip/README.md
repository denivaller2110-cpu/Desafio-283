# Meu Desafio — V11

## Publicação
Envie o conteúdo deste ZIP para o GitHub Pages conforme o fluxo já utilizado.

## Ajuste obrigatório no Supabase (permissões)
No Supabase, abra SQL Editor, execute este SQL e confirme sucesso. Ele concede permissões ao papel autenticado; as políticas RLS existentes continuam controlando o acesso de cada usuário aos próprios registros.

```sql
grant usage on schema public to authenticated;
grant select, insert, update, delete on table public.profiles to authenticated;
grant select, insert, update, delete on table public.challenges to authenticated;
grant select, insert, update, delete on table public.challenge_deposits to authenticated;
```

Não compartilhe a chave `service_role` ou `sb_secret`. O app usa somente a chave publishable.

## Alterações V11
- Login/cadastro e sincronização movidos exclusivamente para Ajustes.
- Botão para mostrar/ocultar senha.
- Atualização do cache do PWA.
