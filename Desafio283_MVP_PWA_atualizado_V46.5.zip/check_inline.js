
(async()=>{
const SUPABASE_URL="https://gkzjwxxwxntvzarksnyt.supabase.co";
const SUPABASE_KEY="sb_publishable_is7WBxm9jMD_VMPfdylotA_yLZddIu5";
async function loadSupabaseLibrary(){
 if(window.supabase?.createClient)return true;
 for(const url of ["https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2","https://unpkg.com/@supabase/supabase-js@2"]){
  try{await new Promise((resolve,reject)=>{const script=document.createElement("script");script.src=url;script.onload=resolve;script.onerror=()=>reject(new Error("Falha ao carregar biblioteca"));document.head.appendChild(script)});if(window.supabase?.createClient)return true;}catch{}
 }
 return false;
}
// Detecta os dois formatos de retorno do Supabase antes que a sessão seja restaurada.
const recoveryHashParams=new URLSearchParams(location.hash.replace(/^#/,""));
const recoveryCode=new URLSearchParams(location.search).get("code");
let passwordRecoveryMode=Boolean(recoveryCode||recoveryHashParams.get("type")==="recovery");
const supabaseAvailable=await loadSupabaseLibrary();
const supabase=supabaseAvailable?window.supabase.createClient(SUPABASE_URL,SUPABASE_KEY):null;
let cloudUser=null, cloudBusy=false, cloudTimer=null, cloudReady=false, activeCompetitionId=null, activeCompetitionCreator=null;
const STORE="meuDesafio-v1", LEGACY="desafio283-v1";
let state=loadState(), selectedId=null, selectedNumber=1, filter="all", challengeFilter="all", editId=null, deferredPrompt=null;
const money=n=>Number(n||0).toLocaleString("pt-BR",{style:"currency",currency:"BRL"});
const today=()=>new Date().toLocaleDateString("en-CA");
const uid=()=> "d"+Date.now().toString(36)+Math.random().toString(36).slice(2,7);
function loadState(){
 try{const saved=JSON.parse(localStorage.getItem(STORE)||"null");if(saved&&Array.isArray(saved.challenges))return saved;}catch{}
 let old={};try{old=JSON.parse(localStorage.getItem(LEGACY)||"{}")}catch{}
 return {version:1,challenges:[{id:"desafio283",name:"Desafio 283",goal:40186,count:283,kind:"sequential",deposits:old&&typeof old==="object"?old:{},createdAt:Date.now()}]};
}
function save(){
 localStorage.setItem(STORE,JSON.stringify(state));
 if(cloudUser&&cloudReady){clearTimeout(cloudTimer);cloudTimer=setTimeout(()=>syncLocalToCloud().catch(e=>setSyncMessage("Falha ao sincronizar: "+(e.message||"verifique sua conexão"))),250)}
}
function setSyncMessage(msg){const el=document.getElementById("syncStatus");if(el)el.textContent=msg}
function mapChallengeToRow(c,userId){
 return {user_id:userId,name:c.name,challenge_type:c.kind==="sequential"?"progressive":"custom",goal_amount:Number(c.goal)||0,status:c.status||"active"};
}
async function syncLocalToCloud(){
 if(!cloudUser||!cloudReady)return;
 while(cloudBusy)await new Promise(resolve=>setTimeout(resolve,100));
 if(!cloudUser||!cloudReady)return;
 cloudBusy=true;const syncingUserId=cloudUser.id;setSyncMessage("Salvando alterações na nuvem...");
 try{
  const {data:remote,error:rErr}=await supabase.from("challenges").select("id").eq("user_id",syncingUserId);
  if(rErr)throw rErr;
  const remoteIds=new Set((remote||[]).map(x=>x.id));
  const localIds=new Set(state.challenges.filter(c=>/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(c.id))).map(c=>c.id));
  for(const c of state.challenges){
   if(cloudUser?.id!==syncingUserId)throw new Error("A conta mudou durante a sincronização.");
   const row=mapChallengeToRow(c,syncingUserId);let challengeId=c.id;
   const isUuid=/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(c.id));
   if(isUuid&&remoteIds.has(c.id)){
    const {error}=await supabase.from("challenges").update(row).eq("id",c.id).eq("user_id",syncingUserId);if(error)throw error;
   }else if(isUuid){
    const {data,error}=await supabase.from("challenges").insert({...row,id:c.id}).select("id").single();if(error)throw error;challengeId=data.id;
   }else{
    const {data,error}=await supabase.from("challenges").insert(row).select("id").single();if(error)throw error;challengeId=data.id;c.id=challengeId;localIds.add(challengeId);
   }
   const {data:remoteSlots,error:slotsErr}=await supabase.from("challenge_deposits").select("*").eq("challenge_id",challengeId);
   if(slotsErr)throw slotsErr;
   const bySlot=new Map((remoteSlots||[]).map(d=>[Number(d.slot_number),d]));
   const count=Math.max(Number(c.count||0),c.kind==="sequential"?283:0);const missing=[];
   for(let n=1;n<=count;n++){
    const localDeposit=c.deposits?.[String(n)],existing=bySlot.get(n),planned=Number(valueFor(c,n));
    if(existing){
     const update={};if(Math.abs(Number(existing.planned_amount)-planned)>0.0001)update.planned_amount=planned;
     if(localDeposit){Object.assign(update,{deposited:true,deposited_amount:Number(localDeposit.value??planned),deposited_at:localDeposit.date?new Date(localDeposit.date+"T12:00:00").toISOString():existing.deposited_at,note:localDeposit.note||null,proof_path:localDeposit.proofPath||null});}
     else if(existing.deposited){Object.assign(update,{deposited:false,deposited_amount:null,deposited_at:null,note:null,proof_path:null});}
     if(Object.keys(update).length){const {error}=await supabase.from("challenge_deposits").update(update).eq("id",existing.id).eq("user_id",syncingUserId);if(error)throw error;}
    }else{
     missing.push({challenge_id:challengeId,user_id:syncingUserId,slot_number:n,planned_amount:planned,deposited:!!localDeposit,deposited_amount:localDeposit?Number(localDeposit.value??planned):null,deposited_at:localDeposit?.date?new Date(localDeposit.date+"T12:00:00").toISOString():null,note:localDeposit?.note||null,proof_path:localDeposit?.proofPath||null});
    }
   }
   for(let i=0;i<missing.length;i+=500){const {error}=await supabase.from("challenge_deposits").insert(missing.slice(i,i+500));if(error)throw error;}
  }
  // Exclusões locais só são propagadas depois de uma carga completa e bem-sucedida da nuvem.
  for(const remoteId of remoteIds){
   if(localIds.has(remoteId))continue;
   const {error:depositDeleteError}=await supabase.from("challenge_deposits").delete().eq("challenge_id",remoteId).eq("user_id",syncingUserId);if(depositDeleteError)throw depositDeleteError;
   const {error:challengeDeleteError}=await supabase.from("challenges").delete().eq("id",remoteId).eq("user_id",syncingUserId);if(challengeDeleteError)throw challengeDeleteError;
  }
  if(cloudUser?.id!==syncingUserId)throw new Error("A conta mudou durante a sincronização.");
  localStorage.setItem(STORE,JSON.stringify(state));setSyncMessage("Tudo sincronizado com a nuvem.");
 }finally{cloudBusy=false;}
}
async function loadCloudToLocal(){
 cloudReady=false;
 const {data:rows,error}=await supabase.from("challenges").select("*").eq("user_id",cloudUser.id).order("created_at",{ascending:true});if(error)throw error;
 if(!rows?.length){
  // Não envia estado local antigo para uma conta sem desafios: isso poderia misturar contas.
  state={version:1,challenges:[]};localStorage.setItem(STORE,JSON.stringify(state));cloudReady=true;render();setSyncMessage("Nenhum desafio encontrado na nuvem.");return;
 }
 const ids=rows.map(r=>r.id);
 let {data:deps,error:dErr}=await supabase.from("challenge_deposits").select("*").in("challenge_id",ids).order("slot_number");if(dErr)throw dErr;
 // Repara somente a estrutura ausente do Desafio 283 progressivo. Insere slots que não
 // existem; não atualiza nem remove nenhum depósito já gravado.
 const existingByChallenge=new Map();(deps||[]).forEach(d=>{if(!existingByChallenge.has(d.challenge_id))existingByChallenge.set(d.challenge_id,new Set());existingByChallenge.get(d.challenge_id).add(Number(d.slot_number));});
 for(const r of rows){
  if(r.challenge_type!=="progressive")continue;
  const present=existingByChallenge.get(r.id)||new Set();
  const missing=[];
  for(let n=1;n<=283;n++)if(!present.has(n))missing.push({challenge_id:r.id,user_id:cloudUser.id,slot_number:n,planned_amount:n,deposited:false});
  if(missing.length){for(let i=0;i<missing.length;i+=500){const {error}=await supabase.from("challenge_deposits").insert(missing.slice(i,i+500));if(error)throw error;}}
 }
 if(rows.some(r=>r.challenge_type==="progressive")){const result=await supabase.from("challenge_deposits").select("*").in("challenge_id",ids).order("slot_number");if(result.error)throw result.error;deps=result.data||[];}
 state={version:1,challenges:rows.map(r=>{
  const ds=(deps||[]).filter(d=>d.challenge_id===r.id);
  const kind=r.challenge_type==="progressive"?"sequential":"custom";
  const values=ds.sort((a,b)=>Number(a.slot_number)-Number(b.slot_number)).map(d=>Number(d.planned_amount));
  const c={id:r.id,name:r.name,goal:Number(r.goal_amount),count:kind==="sequential"?283:ds.length,kind,deposits:{},status:r.status||"active",createdAt:r.created_at?new Date(r.created_at).getTime():Date.now()};
  if(kind==="custom"){c.values=values;c.depositValue=values.length&&values.every(v=>v===values[0])?values[0]:undefined}else if(ds.some((d,i)=>Math.abs(Number(d.planned_amount)-(i+1))>0.0001)){c.values=ds.map(d=>Number(d.planned_amount))}
  ds.forEach(d=>{if(d.deposited)c.deposits[String(d.slot_number)]={date:d.deposited_at?d.deposited_at.slice(0,10):today(),note:d.note||"",value:Number(d.deposited_amount??d.planned_amount),proofPath:d.proof_path||null}});
  return c;
 })};
 localStorage.setItem(STORE,JSON.stringify(state));cloudReady=true;render();setSyncMessage("Dados carregados da nuvem.");
}


const onboardingSteps=[
 {icon:"◈",title:"Seu Desafio 283 já está pronto!",text:"Sua conta gratuita começa com o desafio clássico: 283 depósitos progressivos, de R$ 1 a R$ 283.",highlight:"Meta total: R$ 40.186,00 · Todos os depósitos começam pendentes.",action:"Como funciona"},
 {icon:"✓",title:"Registre cada conquista",text:"Abra o Desafio 283 e toque no número do depósito que você realizou. Informe a data e, se quiser, adicione uma observação.",highlight:"Dica: o progresso e o total economizado são atualizados conforme você registra os depósitos.",action:"Próximo"},
 {icon:"＋",title:"Crie desafios do seu jeito",text:"Além do Desafio 283, use “Novo desafio” para organizar uma viagem, uma reserva ou qualquer outro objetivo, com valores iguais ou personalizados.",highlight:"Seus desafios ficam sincronizados na nuvem e podem ser acessados em outros dispositivos.",action:"Começar a usar"}
];
let onboardingIndex=0;
function finishOnboarding(){if(cloudUser)localStorage.setItem("meuDesafio-onboarding-v1-"+cloudUser.id,"done");document.getElementById("onboarding").hidden=true;}
function showOnboarding(){if(!cloudUser)return;const key="meuDesafio-onboarding-v1-"+cloudUser.id;if(localStorage.getItem(key)==="done")return;onboardingIndex=0;renderOnboardingStep();document.getElementById("onboarding").hidden=false;}
function renderOnboardingStep(){const step=onboardingSteps[onboardingIndex];document.getElementById("onboardingIcon").textContent=step.icon;document.getElementById("onboardingTitle").textContent=step.title;document.getElementById("onboardingText").textContent=step.text;document.getElementById("onboardingHighlight").textContent=step.highlight;document.getElementById("onboardingNext").textContent=onboardingIndex===onboardingSteps.length-1?"Começar a usar":step.action;document.getElementById("onboardingBack").hidden=onboardingIndex===0;document.querySelectorAll(".onboarding-dots span").forEach((dot,i)=>dot.classList.toggle("active",i===onboardingIndex));}
document.getElementById("onboardingNext").onclick=()=>{if(onboardingIndex<onboardingSteps.length-1){onboardingIndex++;renderOnboardingStep()}else{finishOnboarding();showView("challenges")}};
document.getElementById("onboardingBack").onclick=()=>{if(onboardingIndex>0){onboardingIndex--;renderOnboardingStep()}};
document.getElementById("onboardingSkip").onclick=finishOnboarding;
document.getElementById("openTutorialBtn").onclick=()=>{onboardingIndex=0;renderOnboardingStep();document.getElementById("onboarding").hidden=false;};

function updateBrandDisplayName(name){const el=document.getElementById("brandDisplayName");if(el)el.textContent=(name||"").trim()||"Meu Desafio";}
async function activateSession(session){
 cloudUser=session?.user||null;cloudReady=false;updateBrandDisplayName("Meu Desafio");
 const panel=document.getElementById("authPanel"),form=document.getElementById("authForm"),account=document.getElementById("accountPanel");
 if(!panel)return;
 if(cloudUser){
  form.hidden=true;account.hidden=false;document.getElementById("authMessage").hidden=true;
  document.getElementById("accountHeading").textContent="Sua conta está conectada";
  document.getElementById("accountDescription").textContent="Seus desafios estão vinculados à sua conta e podem ser acessados em outros dispositivos.";
  document.getElementById("accountEmail").textContent=cloudUser.email||"Conta conectada";
  setSyncMessage("Conectado. Carregando seus dados da nuvem...");
  try{
   const {data:profile,error:profileError}=await supabase.from("profiles").select("display_name,avatar_url").eq("id",cloudUser.id).maybeSingle();
   if(profileError)throw profileError;
   const metadataName=cloudUser.user_metadata?.full_name||cloudUser.user_metadata?.name||cloudUser.user_metadata?.display_name||"";
   const suggested=profile?.display_name||metadataName||"";
   document.getElementById("profileName").value=suggested;updateBrandDisplayName(suggested);document.getElementById("profileAvatarPreview").src=profile?.avatar_url||"icon-192.png";document.getElementById("headerAvatar").src=profile?.avatar_url||"icon-192.png";
   if(!profile?.display_name && metadataName){const {error}=await supabase.from("profiles").upsert({id:cloudUser.id,display_name:metadataName},{onConflict:"id"});if(error)throw error;}
   document.getElementById("profileDescription").textContent="Nome associado à sua conta e sincronizado na nuvem. Você pode alterá-lo quando quiser.";
   // Garante o desafio padrão para contas sem desafios, sem criar duplicatas.
   const {error:defaultChallengeError}=await supabase.rpc("ensure_default_challenge");
   if(defaultChallengeError)throw defaultChallengeError;
   await loadCloudToLocal();
   await loadCompetitions();
   setTimeout(showOnboarding,500);
  }catch(e){setSyncMessage("Não foi possível sincronizar: "+(e.message||"verifique as permissões"))}
  }else{
  clearTimeout(cloudTimer);cloudTimer=null;cloudUser=null;cloudReady=false;selectedId=null;state={version:1,challenges:[]};
  document.getElementById("authEmail").value="";document.getElementById("authPassword").value="";document.getElementById("signupName").value="";document.getElementById("detail").hidden=true;
  form.hidden=false;account.hidden=true;document.getElementById("authMessage").hidden=false;document.getElementById("profileName").value="";
  document.getElementById("accountHeading").textContent="Entre na sua conta";
  document.getElementById("accountDescription").textContent="Seus desafios ficarão salvos na nuvem e poderão ser acessados em outros dispositivos.";
  document.getElementById("profileDescription").textContent="Entre na sua conta para manter seu nome sincronizado em outros dispositivos.";
  setSyncMessage("Entre ou crie uma conta para ativar a sincronização.")
 }
}
document.getElementById("togglePassword").onclick=()=>{const input=document.getElementById("authPassword"),btn=document.getElementById("togglePassword"),show=input.type==="password";input.type=show?"text":"password";btn.textContent=show?"◎":"◉";btn.setAttribute("aria-label",show?"Ocultar senha":"Mostrar senha");btn.setAttribute("aria-pressed",String(show));};
document.getElementById("authForm").addEventListener("submit",async e=>{
 e.preventDefault();const email=document.getElementById("authEmail").value.trim(),password=document.getElementById("authPassword").value;
 document.getElementById("authMessage").textContent="Entrando...";
 if(!supabase){document.getElementById("authMessage").textContent="Não foi possível carregar o serviço de acesso. Verifique sua conexão e atualize a página.";return}
 if(!supabase){document.getElementById("authMessage").textContent="Não foi possível carregar o serviço de acesso. Verifique sua conexão e atualize a página.";return}
 const {data,error}=await supabase.auth.signInWithPassword({email,password});
 if(error)document.getElementById("authMessage").textContent=error.message;else await activateSession(data.session);
});
const recoveryModal=document.getElementById("recoveryEmailModal");
function closeRecoveryModal(){recoveryModal.hidden=true;document.getElementById("recoveryModalMessage").textContent="";}
document.getElementById("forgotPasswordBtn").onclick=()=>{
 const currentEmail=document.getElementById("authEmail").value.trim();
 document.getElementById("recoveryEmail").value=currentEmail;
 document.getElementById("recoveryModalMessage").textContent="";
 recoveryModal.hidden=false;
 setTimeout(()=>document.getElementById("recoveryEmail").focus(),50);
};
document.getElementById("closeRecoveryModal").onclick=closeRecoveryModal;
document.getElementById("cancelRecovery").onclick=closeRecoveryModal;
document.getElementById("sendRecoveryEmail").onclick=async()=>{
 const email=document.getElementById("recoveryEmail").value.trim(),msg=document.getElementById("recoveryModalMessage"),btn=document.getElementById("sendRecoveryEmail");
 if(!email){msg.textContent="Informe o e-mail da sua conta.";document.getElementById("recoveryEmail").focus();return}
 if(!supabase){msg.textContent="Serviço de acesso indisponível. Verifique sua conexão.";return}
 btn.disabled=true;msg.textContent="Enviando link...";
 const {error}=await supabase.auth.resetPasswordForEmail(email,{redirectTo:location.origin+location.pathname});
 btn.disabled=false;
 msg.textContent=error?"Não foi possível enviar o link: "+error.message:"Se houver uma conta para esse e-mail, enviaremos o link de recuperação. Confira sua caixa de entrada e o spam.";
 if(!error){document.getElementById("authMessage").textContent="Solicitação enviada. Confira seu e-mail para continuar.";setTimeout(closeRecoveryModal,1800)}
};
document.getElementById("saveNewPasswordBtn").onclick=async()=>{
 const password=document.getElementById("newPassword").value,confirm=document.getElementById("confirmNewPassword").value,msg=document.getElementById("authMessage");
 if(password.length<8){msg.textContent="A nova senha precisa ter pelo menos 8 caracteres.";return}
 if(password!==confirm){msg.textContent="As senhas não coincidem. Confira e tente novamente.";return}
 const {error}=await supabase.auth.updateUser({password});
 if(error){msg.textContent="Não foi possível atualizar a senha: "+error.message;return}
 await supabase.auth.signOut();
 passwordRecoveryMode=false;cloudUser=null;selectedId=null;state={version:1,challenges:[]};
 document.getElementById("passwordRecoveryPanel").hidden=true;
 document.getElementById("authForm").hidden=false;
 document.getElementById("accountPanel").hidden=true;
 document.getElementById("authEmail").value="";
 document.getElementById("authPassword").value="";
 document.getElementById("newPassword").value="";document.getElementById("confirmNewPassword").value="";
 document.getElementById("accountHeading").textContent="Entre ou crie sua conta";
 document.getElementById("accountDescription").textContent="Acesse seus desafios em qualquer dispositivo.";
 document.getElementById("authMessage").hidden=false;
 msg.textContent="Senha atualizada! Agora entre usando sua nova senha.";
 history.replaceState({},document.title,location.pathname+"?v=22");
 render();renderProgress();
};
document.getElementById("signupBtn").onclick=async()=>{
 const email=document.getElementById("authEmail").value.trim(),password=document.getElementById("authPassword").value;
 const displayName=document.getElementById("signupName").value.trim();
 if(!displayName){document.getElementById("authMessage").textContent="Informe seu nome de exibição para criar a conta.";return}
 if(!email||password.length<8){document.getElementById("authMessage").textContent="Informe um e-mail válido e uma senha com pelo menos 8 caracteres.";return}
 if(!supabase){document.getElementById("authMessage").textContent="Não foi possível carregar o serviço de acesso. Verifique sua conexão e atualize a página.";return}
 if(!supabase){document.getElementById("authMessage").textContent="Não foi possível carregar o serviço de acesso. Verifique sua conexão e atualize a página.";return}
 document.getElementById("authMessage").textContent="Criando sua conta...";
 const {data,error}=await supabase.auth.signUp({email,password,options:{emailRedirectTo:location.href.split("#")[0],data:{full_name:displayName,name:displayName,display_name:displayName}}});
 document.getElementById("authMessage").textContent=error?error.message:(data.session?"Conta criada!": "Conta criada. Confirme seu e-mail pelo link que enviamos antes de entrar.");
 if(data.session)await activateSession(data.session);
};
document.getElementById("logoutBtn").onclick=async()=>{
 if(!supabase)return;clearTimeout(cloudTimer);cloudTimer=null;
 const {error}=await supabase.auth.signOut();if(error){setSyncMessage("Não foi possível sair: "+error.message);return}
 cloudUser=null;selectedId=null;state={version:1,challenges:[]};
 document.getElementById("authEmail").value="";document.getElementById("authPassword").value="";document.getElementById("signupName").value="";document.getElementById("detail").hidden=true;
 render();renderProgress();await activateSession(null);
};
document.getElementById("deleteAccountBtn").onclick=async()=>{
 if(!cloudUser||!supabase)return;
 const first=confirm("Excluir sua conta permanentemente? Seus desafios, depósitos e perfil na nuvem também serão apagados. Esta ação não pode ser desfeita.");
 if(!first)return;
 const second=prompt('Para confirmar, digite EXCLUIR.');
 if(second!=="EXCLUIR"){toast("Exclusão cancelada.");return}
 const btn=document.getElementById("deleteAccountBtn");btn.disabled=true;btn.textContent="Excluindo conta...";
 try{
  const {data,error}=await supabase.functions.invoke("delete-account");
  if(error)throw error;
  clearTimeout(cloudTimer);cloudTimer=null;
  await supabase.auth.signOut();
  cloudUser=null;selectedId=null;state={version:1,challenges:[]};localStorage.setItem(STORE,JSON.stringify(state));
  document.getElementById("detail").hidden=true;render();renderProgress();await activateSession(null);
  document.getElementById("authMessage").textContent="Sua conta e seus dados foram excluídos.";toast("Conta excluída com sucesso.");
 }catch(e){setSyncMessage("Não foi possível excluir a conta: "+(e.message||"erro no servidor"));}
 finally{btn.disabled=false;btn.textContent="Excluir minha conta"}
};
document.getElementById("syncNowBtn").onclick=()=>syncLocalToCloud().catch(e=>setSyncMessage("Falha: "+(e.message||"erro de sincronização")));
function showPasswordRecoveryPanel(){
 showView("settings");
 document.getElementById("passwordRecoveryPanel").hidden=false;
 document.getElementById("authForm").hidden=true;
 document.getElementById("accountPanel").hidden=true;
 document.getElementById("authMessage").hidden=false;
 document.getElementById("authMessage").textContent="Link validado. Cadastre sua nova senha abaixo.";
 document.getElementById("accountHeading").textContent="Recuperar senha";
 document.getElementById("accountDescription").textContent="Escolha uma nova senha para sua conta.";
 document.getElementById("authPanel").scrollIntoView({behavior:"smooth",block:"start"});
}
if(supabase){
 supabase.auth.onAuthStateChange((event,session)=>{
  if(event==="PASSWORD_RECOVERY")passwordRecoveryMode=true;
  setTimeout(()=>{
  if(event==="PASSWORD_RECOVERY"){
   passwordRecoveryMode=true;
   showPasswordRecoveryPanel();
   return;
  }
  if(passwordRecoveryMode)return;
  if(!session){cloudUser=null;selectedId=null;state={version:1,challenges:[]};render();renderProgress();activateSession(null)}
  else if(session.user?.id!==cloudUser?.id)activateSession(session)
 },0)});
 if(recoveryCode){
  supabase.auth.exchangeCodeForSession(recoveryCode).then(({error})=>{
   if(error){passwordRecoveryMode=false;document.getElementById("authMessage").textContent="Não foi possível validar o link de recuperação. Solicite um novo link e abra-o novamente.";return;}
   passwordRecoveryMode=true;
   history.replaceState({},document.title,location.pathname+"?v=22");
   showPasswordRecoveryPanel();
  });
 }
 supabase.auth.getSession().then(({data})=>{
  if(passwordRecoveryMode){
   if(data.session){showPasswordRecoveryPanel();history.replaceState({},document.title,location.pathname+"?v=22");}
   return;
  }
  activateSession(data.session);
 });
}else{
 document.getElementById("authMessage").textContent="Serviço de acesso indisponível no momento. Confira a internet e atualize a página.";
}

function toast(msg){const t=document.getElementById("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200)}
function valueFor(c,n){if(c.kind==="sequential")return Number(c.values?.[n-1]??n);if(c.kind==="custom")return Number(c.values?.[n-1]||0);return Number(c.depositValue||0)}
function distributeSequentialGoal(goal,count=283){
 // Distribui a meta em reais inteiros, proporcionalmente aos pesos 1..count.
 const totalReais=Number(goal);if(!Number.isSafeInteger(totalReais)||totalReais<count)return null;
 const weightSum=count*(count+1)/2;
 const shares=Array.from({length:count},(_,i)=>{const exact=totalReais*(i+1)/weightSum;const base=Math.floor(exact);return {index:i,reais:base,fraction:exact-base}});
 let remainder=totalReais-shares.reduce((sum,x)=>sum+x.reais,0);
 // O primeiro quadradinho sempre arredonda para cima quando houver fração.
 if(shares[0].fraction>0&&remainder>0){shares[0].reais++;remainder--;}
 shares.slice(1).sort((a,b)=>b.fraction-a.fraction||a.index-b.index).slice(0,remainder).forEach(x=>x.reais++);
 const result=shares.map(x=>x.reais);
 return result.every(Number.isSafeInteger)&&result.reduce((a,b)=>a+b,0)===totalReais?result:null;
}
function totals(c){const nums=Object.keys(c.deposits||{}).map(Number);const sum=nums.reduce((a,n)=>a+Number(c.deposits[n]?.value??valueFor(c,n)),0);return {count:nums.length,sum,goal:Number(c.goal)||0,depositCount:Number(c.count)||0}}
const financeMilestones=[
 {pct:1,name:"Primeiro passo",icon:"🌱",subtitle:"Seu objetivo começou a sair do papel."},
 {pct:2.5,name:"Primeiro impulso",icon:"💵",subtitle:"Você já colocou dinheiro em movimento."},
 {pct:5,name:"Cofrinho crescendo",icon:"💰",subtitle:"Seu esforço começa a aparecer."},
 {pct:10,name:"Dez por cento",icon:"🌿",subtitle:"Você já percorreu a primeira etapa."},
 {pct:20,name:"Ritmo constante",icon:"🪙",subtitle:"Continue, cada depósito conta."},
 {pct:30,name:"Foco no objetivo",icon:"🎯",subtitle:"Trinta por cento da meta alcançada."},
 {pct:50,name:"Metade do caminho",icon:"🥉",subtitle:"Você chegou à metade do desafio."},
 {pct:65,name:"Investidor de prata",icon:"🥈",subtitle:"Seu progresso está cada vez maior."},
 {pct:80,name:"Reta final",icon:"🥇",subtitle:"Falta pouco para a conquista."},
 {pct:90,name:"Quase lá",icon:"💎",subtitle:"Você está muito perto."},
 {pct:100,name:"Missão cumprida",icon:"🏆",subtitle:"Você alcançou a meta deste desafio!"}
];
const depositMilestones=[
 {pct:1,fixed:1,name:"Iniciante",icon:"🐣",subtitle:"Seu primeiro depósito foi registrado."},
 {pct:5,fixed:5,name:"Pegando o ritmo",icon:"🐾",subtitle:"Você está criando consistência."},
 {pct:10,fixed:10,name:"Comprometido",icon:"⚡",subtitle:"Dez por cento dos depósitos concluídos."},
 {pct:25,name:"Constância",icon:"🔥",subtitle:"Um quarto dos depósitos concluídos."},
 {pct:50,name:"Meio caminho",icon:"🚀",subtitle:"Metade dos depósitos realizados."},
 {pct:75,name:"Determinação",icon:"🦾",subtitle:"Você está chegando ao fim."},
 {pct:90,name:"Quase finalizando",icon:"🏅",subtitle:"Falta muito pouco."},
 {pct:100,name:"Colecionador de depósitos",icon:"🏆",subtitle:"Todos os depósitos deste desafio foram realizados."}
];
const journeyMilestones=[
 {pct:1,name:"Jornada iniciada",icon:"🧭",subtitle:"Seu desafio já está em andamento."},
 {pct:25,name:"Primeira etapa",icon:"🛤️",subtitle:"Você completou um quarto dos depósitos."},
 {pct:50,name:"Metade da jornada",icon:"🧗",subtitle:"Metade dos depósitos concluída."},
 {pct:75,name:"Última etapa",icon:"🚩",subtitle:"Você está chegando ao fim."},
 {pct:100,name:"Desafio concluído",icon:"🏁",subtitle:"Você concluiu este objetivo."}
];
function makeMilestones(c,group){
 const t=totals(c),count=Math.max(1,t.depositCount),goal=Math.max(0,t.goal);
 const source=group==="finance"?financeMilestones:group==="deposits"?depositMilestones:journeyMilestones;
 // Cada desafio recebe marcos próprios: desafios curtos distribuem as conquistas
 // por todos os depósitos; desafios longos usam percentuais, sem repetir etapas.
 const milestoneCount=group==="finance"?source.length:Math.min(count,source.length);
 const selected=Array.from({length:milestoneCount},(_,i)=>{
  const sourceIndex=milestoneCount===1?source.length-1:Math.round(i*(source.length-1)/(milestoneCount-1));
  const slot=Math.max(1,Math.ceil((i+1)*count/milestoneCount));
  return {...source[sourceIndex],slot};
 });
 const plannedTotal=Array.from({length:count},(_,i)=>Math.max(0,valueFor(c,i+1))).reduce((a,v)=>a+v,0);
 const cumulativeAt=slot=>Array.from({length:slot},(_,i)=>Math.max(0,valueFor(c,i+1))).reduce((a,v)=>a+v,0);
 let previousTarget=0;
 return selected.map((m,i)=>{
  const target=group==="finance"?((goal||plannedTotal)*m.pct/100):m.slot;
  const current=group==="finance"?t.sum:t.count;
  const unlocked=current+0.000001>=target;
  const progress=unlocked?100:Math.max(0,Math.min(100,(current-previousTarget)/(target-previousTarget||target||1)*100));
  const remaining=Math.max(0,target-current);
  previousTarget=target;
  return {...m,id:group+"-"+i,group,target,unlocked,progress,remaining,displayTarget:group==="finance"?`${money(target)} acumulados`:`${m.slot} ${m.slot===1?'depósito':'depósitos'}`};
 });
}
function achievementsFor(c){return {finance:makeMilestones(c,"finance"),deposits:makeMilestones(c,"deposits"),journey:makeMilestones(c,"journey")}}
let activeAchievementFilter="all";
let expandedAchievementChallengeId=null;
function renderAchievements(){
 const summary=document.getElementById("achievementSummary"),container=document.getElementById("achievementChallenges");
 if(!summary||!container)return;
 if(!cloudUser){summary.innerHTML='<div class="empty">Entre na sua conta para visualizar suas conquistas.</div>';container.innerHTML="";return}
 const all=state.challenges||[];
 const allBadges=all.flatMap(c=>Object.values(achievementsFor(c)).flat());
 const unlocked=allBadges.filter(a=>a.unlocked).length,total=allBadges.length;
 summary.innerHTML=`<div class="achievement-hero"><span class="achievement-hero-icon">🏆</span><span><strong>${unlocked} de ${total}</strong><small>conquistas desbloqueadas em ${all.length} desafio(s)</small></span></div><div class="achievement-list-heading"><h2>Meus desafios</h2><p>Selecione um desafio para visualizar suas conquistas.</p></div>`;
 container.innerHTML=all.length?all.map(c=>{
  const groups=achievementsFor(c),flat=Object.values(groups).flat();
  const won=flat.filter(a=>a.unlocked).length, pct=flat.length?Math.round(won/flat.length*100):0;
  const expanded=expandedAchievementChallengeId===c.id;
  const categoryTabs=`<div class="achievement-tabs" role="tablist" aria-label="Categorias de conquistas de ${esc(c.name)}">
   <button type="button" class="achievement-tab ${activeAchievementFilter==='all'?'active':''}" data-achievement-tab="all">Todas</button>
   <button type="button" class="achievement-tab ${activeAchievementFilter==='finance'?'active':''}" data-achievement-tab="finance">Financeiro</button>
   <button type="button" class="achievement-tab ${activeAchievementFilter==='deposits'?'active':''}" data-achievement-tab="deposits">Depósitos</button>
   <button type="button" class="achievement-tab ${activeAchievementFilter==='journey'?'active':''}" data-achievement-tab="journey">Jornada</button>
  </div>`;
  const shown=activeAchievementFilter==='all'?Object.entries(groups):[[activeAchievementFilter,groups[activeAchievementFilter]]];
  const details=shown.map(([key,items])=>{
   const title=key==='finance'?'💰 Evolução financeira':key==='deposits'?'🎯 Quantidade de depósitos':'🧭 Jornada do desafio';
   const desc=key==='finance'?'Marcos calculados automaticamente sobre a meta deste desafio.':key==='deposits'?'Conquistas proporcionais à quantidade de depósitos planejados.':'Etapas especiais para acompanhar a conclusão do objetivo.';
   return `<section class="achievement-category"><h3>${title}</h3><p>${desc}</p><div class="achievement-grid">${items.map(a=>`<article class="achievement-card ${a.unlocked?'unlocked':''}"><div class="achievement-medal">${a.unlocked?a.icon:'🔒'}</div><div class="achievement-info"><b>${a.name}</b><small>${a.displayTarget}</small><div class="achievement-status">${a.unlocked?'Desbloqueada':`Faltam ${a.group==='deposits'?Math.ceil(a.remaining)+' depósitos':money(a.remaining)}`}</div><div class="achievement-mini-track"><span style="width:${a.progress}%"></span></div></div></article>`).join('')}</div></section>`;
  }).join('');
  return `<section class="achievement-challenge ${expanded?'expanded':''}">
   <button type="button" class="achievement-challenge-toggle" data-achievement-challenge="${esc(c.id)}" aria-expanded="${expanded}">
    <span class="achievement-challenge-symbol">${c.kind==='sequential'?'📅':'🎯'}</span>
    <span class="achievement-challenge-main"><b>${esc(c.name)}</b><small>Meta: ${money(totals(c).goal)} <i>•</i> ${totals(c).depositCount} depósitos</small></span>
    <span class="achievement-challenge-progress"><b>${won}/${flat.length}</b><small>conquistas</small></span>
    <span class="achievement-chevron">${expanded?'⌃':'⌄'}</span>
   </button>
   ${expanded?`<div class="achievement-challenge-content"><div class="achievement-challenge-progressbar"><div><b>Progresso do desafio</b><strong>${pct}%</strong></div><span><i style="width:${pct}%"></i></span><small>${won} de ${flat.length} conquistas</small></div>${categoryTabs}${details}</div>`:''}
  </section>`;
 }).join(''):'<div class="empty">Crie seu primeiro desafio para começar a conquistar medalhas.</div>';
}
document.getElementById("achievementChallenges").addEventListener("click",e=>{
 const toggle=e.target.closest("[data-achievement-challenge]");
 if(toggle){const id=toggle.dataset.achievementChallenge;expandedAchievementChallengeId=expandedAchievementChallengeId===id?null:id;activeAchievementFilter="all";renderAchievements();return}
 const tab=e.target.closest("[data-achievement-tab]");
 if(tab){activeAchievementFilter=tab.dataset.achievementTab;renderAchievements()}
});
let celebrationQueue=[];
function showNextCelebration(){if(!celebrationQueue.length){document.getElementById("celebration").hidden=true;return}const item=celebrationQueue.shift();document.getElementById("celebrationMedal").textContent=item.icon;document.getElementById("celebrationTitle").textContent=item.name+" desbloqueada!";document.getElementById("celebrationText").textContent=`${(item.group==="deposits"||item.group==="journey")?"Você concluiu "+Math.round(item.amount)+" depósitos": "Você alcançou "+money(item.amount)+" em depósitos"} no desafio ${item.challengeName}. ${item.subtitle}`;document.getElementById("celebration").hidden=false}
document.getElementById("closeCelebration").onclick=showNextCelebration;
function celebrateNewAchievements(c,previousTotal,newTotal,previousCount=totals(c).count,newCount=totals(c).count){
 if(newTotal<previousTotal)return;
 const groups=achievementsFor(c);
 groups.finance.forEach(a=>{if(previousTotal+0.000001<a.target&&newTotal+0.000001>=a.target)celebrationQueue.push({...a,challengeName:c.name,amount:a.target})});
 groups.deposits.forEach(a=>{if(previousCount<a.target&&newCount>=a.target)celebrationQueue.push({...a,challengeName:c.name,amount:a.target})});
 groups.journey.forEach(a=>{if(previousCount<a.target&&newCount>=a.target)celebrationQueue.push({...a,challengeName:c.name,amount:a.target})});
 if(celebrationQueue.length&&document.getElementById("celebration").hidden)showNextCelebration()
}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}

function renderHomeHighlights(){
 const box=document.getElementById("homeChallenges"),next=document.getElementById("homeNextDeposits");
 if(!cloudUser){box.innerHTML='<div class="empty">Entre na sua conta para visualizar seus desafios.</div>';next.innerHTML='<div class="empty">Entre na sua conta para visualizar os próximos depósitos.</div>';return}
 const all=state.challenges||[];
 const active=all.filter(c=>c.status!=="paused"&&c.status!=="completed"&&!(totals(c).goal>0&&totals(c).sum>=totals(c).goal));
 const items=active.slice(0,3);
 box.innerHTML=items.length?items.map(c=>{const t=totals(c),pct=t.goal?Math.min(100,t.sum/t.goal*100):0;return `<div class="home-mini home-challenge-card"><div style="display:flex;justify-content:space-between;align-items:flex-start;gap:10px"><span><b>${esc(c.name)}</b><small>${money(t.sum)} acumulados de ${money(t.goal)}</small></span><strong>${pct.toFixed(1).replace(".",",")}%</strong></div><div class="home-mini-progress"><span style="width:${pct}%"></span></div><div class="home-mini-meta"><span>${t.count} de ${t.depositCount} depósitos</span><span>Faltam ${money(Math.max(0,t.goal-t.sum))}</span></div></div>`}).join(""):'<div class="empty">Nenhum desafio em andamento no momento.</div>';
 const upcoming=active.map(c=>{const t=totals(c);let n=0;for(let i=1;i<=t.depositCount;i++){if(!c.deposits?.[i]){n=i;break}}return n?{c,n,value:valueFor(c,n)}:null}).filter(Boolean).slice(0,3);
 next.innerHTML=upcoming.length?upcoming.map(x=>`<div class="home-mini"><span><b>${esc(x.c.name)}</b><small>Próximo depósito · Nº ${x.n}</small><span class="home-next-label">Valor do próximo passo</span><span class="home-next">${money(x.value)}</span></span><button class="secondary" type="button" data-home-open="${esc(x.c.id)}">Continuar</button></div>`).join(""):'<div class="empty">Você já registrou todos os depósitos dos desafios ativos. Mandou bem!</div>';
 next.querySelectorAll("[data-home-open]").forEach(b=>b.onclick=()=>{showView("challenges");openChallenge(b.dataset.homeOpen)});
}

function renderProgress(){
 if(!cloudUser){document.getElementById("progressSaved").textContent=money(0);document.getElementById("progressPercent").textContent="0,0%";document.getElementById("progressDeposits").textContent="0";document.getElementById("progressCompleted").textContent="0";document.getElementById("progressChallenges").innerHTML='<div class="empty">Entre na sua conta para visualizar seu progresso.</div>';document.getElementById("allHistory").innerHTML='<div class="empty">Entre na sua conta para visualizar seu histórico.</div>';renderAchievements();return}
 const all=state.challenges||[];let sum=0,goals=0,deposits=0,completed=0,records=[];
 all.forEach(c=>{const t=totals(c);sum+=t.sum;goals+=t.goal;deposits+=t.count;if(c.status==="completed"||(t.goal>0&&t.sum>=t.goal))completed++;
 Object.keys(c.deposits||{}).forEach(n=>{const d=c.deposits[n];records.push({name:c.name,n:Number(n),date:d.date||"",value:Number(d.value??valueFor(c,Number(n)))})})});
 document.getElementById("progressSaved").textContent=money(sum);document.getElementById("progressPercent").textContent=(goals?Math.min(100,sum/goals*100):0).toFixed(1).replace(".",",")+"%";document.getElementById("progressDeposits").textContent=deposits;document.getElementById("progressCompleted").textContent=completed;
 document.getElementById("progressChallenges").innerHTML=all.length?all.map(c=>{const t=totals(c),pct=t.goal?Math.min(100,t.sum/t.goal*100):0;return `<div class="progress-line"><div class="progress-line-head"><span>${esc(c.name)}</span><span>${pct.toFixed(1).replace(".",",")}%</span></div><small>${money(t.sum)} de ${money(t.goal)}</small><div class="progress-track"><span style="width:${pct}%"></span></div></div>`}).join(""):'<div class="empty">Crie seu primeiro desafio para acompanhar o progresso.</div>';
 records.sort((a,b)=>String(b.date).localeCompare(String(a.date)));records=records.slice(0,12);
 document.getElementById("allHistory").innerHTML=records.length?records.map(r=>`<div class="history-row"><span><b>${esc(r.name)} · Depósito ${r.n}</b><small>${r.date?new Date(r.date+"T12:00:00").toLocaleDateString("pt-BR"):"Data não informada"}</small></span><span class="history-value">${money(r.value)}</span></div>`).join(""):'<div class="empty">Seus depósitos aparecerão aqui.</div>';
 renderAchievements();
}

function render(){
 const list=document.getElementById("challengeList"),detail=document.getElementById("detail");
 if(!cloudUser){document.getElementById("totalSaved").textContent=money(0);document.getElementById("completedCount").textContent="0";document.getElementById("totalDeposits").textContent="0";document.getElementById("totalGoals").textContent=money(0);document.getElementById("remainingTotal").textContent=money(0);document.getElementById("activeCount").textContent="0 desafios ativos";document.getElementById("homePercent").textContent="0%";document.getElementById("homeProgressBar").style.width="0%";document.getElementById("homeChallenges").innerHTML='<div class="empty">Entre na sua conta para visualizar seus desafios.</div>';document.getElementById("homeNextDeposits").innerHTML='<div class="empty">Entre na sua conta para visualizar os próximos depósitos.</div>';list.innerHTML='<div class="empty">Entre na sua conta para acessar seus desafios.</div>';detail.hidden=true;selectedId=null;return}
 const all=state.challenges||[];let sum=0,goals=0,done=0,deposits=0,active=0;
 all.forEach(c=>{
  const t=totals(c);
  sum+=t.sum;goals+=t.goal;deposits+=t.count;
  const reachedGoal=t.goal>0&&t.sum>=t.goal;
  const isCompleted=c.status==="completed"||reachedGoal;
  const isPaused=c.status==="paused";
  if(isCompleted)done++;
  else if(!isPaused)active++;
 });
 document.getElementById("totalSaved").textContent=money(sum);document.getElementById("completedCount").textContent=done;document.getElementById("totalDeposits").textContent=all.reduce((a,c)=>a+totals(c).count,0);document.getElementById("totalGoals").textContent=money(goals);document.getElementById("remainingTotal").textContent=money(Math.max(0,goals-sum));document.getElementById("activeCount").textContent=active+" desafios ativos";const overallPct=goals?Math.min(100,sum/goals*100):0;document.getElementById("homePercent").textContent=overallPct.toFixed(1).replace(".",",")+"%";document.getElementById("homeProgressBar").style.width=overallPct+"%";renderHomeHighlights();
 document.getElementById("view-challenges").appendChild(detail);
 list.innerHTML="";
 if(!all.length){list.innerHTML='<div class="empty">Você ainda não criou nenhum desafio. Que tal começar agora?</div>'}
 all.forEach(c=>{const t=totals(c),pct=t.goal?Math.min(100,t.sum/t.goal*100):0,remaining=Math.max(0,t.goal-t.sum),isDone=c.status==="completed"||(t.sum>=t.goal&&t.goal>0),isPaused=c.status==="paused";
 if(challengeFilter==="active"&&(isDone||isPaused)||challengeFilter==="paused"&&!isPaused||challengeFilter==="completed"&&!isDone)return;
 const el=document.createElement("article");el.className="challenge";
 el.innerHTML=`<div class="challenge-head"><div><h3>${esc(c.name)}</h3><p class="desc">${c.kind==="sequential"?"Depósitos de valores progressivos":c.kind==="custom"?"Depósitos com valores personalizados":t.depositCount+" depósitos planejados"}</p></div><div class="challenge-head-tools"><span class="status">${isDone?"Concluído":isPaused?"Pausado":"Em andamento"}</span><div class="challenge-menu-wrap"><button type="button" class="challenge-menu-trigger" data-menu="${esc(c.id)}" aria-label="Mais opções para ${esc(c.name)}" aria-expanded="false">⋮</button><div class="challenge-menu" data-menu-panel="${esc(c.id)}"><button type="button" data-edit="${esc(c.id)}" ${c.kind==="sequential"?'hidden':''}>Editar</button><button type="button" data-toggle="${esc(c.id)}">${isPaused?"Retomar":"Pausar"}</button><button type="button" data-complete="${esc(c.id)}">${isDone?"Reabrir":"Concluir"}</button><button type="button" class="menu-danger" data-delete="${esc(c.id)}">Excluir desafio</button></div></div></div></div><div class="challenge-total">${money(t.sum)}</div><div class="challenge-meta"><span>Meta: ${money(t.goal)}</span><span>${pct.toFixed(1).replace(".",",")}%</span></div><div class="track"><div class="fill" style="width:${pct}%"></div></div><div class="challenge-meta" style="margin-bottom:12px"><span>${t.count} depósitos feitos</span><span>Faltam ${money(remaining)}</span></div><div class="challenge-actions"><button class="primary" data-open="${esc(c.id)}">Abrir desafio</button>${c.kind==="sequential"?`<button class="secondary" data-edit="${esc(c.id)}">Alterar a meta</button>`:''}</div>`;
 list.appendChild(el);
  if(selectedId===c.id){detail.hidden=false;el.appendChild(detail);}
 });
 list.querySelectorAll("[data-menu]").forEach(b=>b.onclick=e=>{e.stopPropagation();const id=b.dataset.menu,panel=list.querySelector(`[data-menu-panel="${id}"]`);list.querySelectorAll(".challenge-menu.open").forEach(x=>{if(x!==panel)x.classList.remove("open")});const opened=panel?.classList.toggle("open");b.setAttribute("aria-expanded",String(!!opened))});
 list.querySelectorAll("[data-open]").forEach(b=>b.onclick=()=>openChallenge(b.dataset.open));
 list.querySelectorAll("[data-edit]").forEach(b=>b.onclick=()=>editChallenge(b.dataset.edit));
 list.querySelectorAll("[data-delete]").forEach(b=>b.onclick=async()=>{const c=state.challenges.find(x=>x.id===b.dataset.delete);if(c&&confirm(`Excluir "${c.name}" e todo o histórico? Esta ação não pode ser desfeita.`)){state.challenges=state.challenges.filter(x=>x.id!==c.id);if(selectedId===c.id){selectedId=null;document.getElementById("detail").hidden=true}save();render();renderProgress();try{await syncLocalToCloud();toast("Desafio excluído e sincronizado.")}catch(e){setSyncMessage("A exclusão ainda não foi confirmada na nuvem: "+(e.message||"verifique sua conexão"));toast("Não foi possível confirmar a exclusão na nuvem.")}}});
 list.querySelectorAll("[data-toggle]").forEach(b=>b.onclick=()=>{const c=state.challenges.find(x=>x.id===b.dataset.toggle);if(!c)return;c.status=c.status==="paused"?"active":"paused";save();render();toast(c.status==="paused"?"Desafio pausado.":"Desafio retomado.")});
 list.querySelectorAll("[data-complete]").forEach(b=>b.onclick=()=>{const c=state.challenges.find(x=>x.id===b.dataset.complete);if(!c)return;c.status=c.status==="completed"?"active":"completed";save();render();toast(c.status==="completed"?"Desafio concluído.":"Desafio reaberto.")});
 if(selectedId&&!all.some(c=>c.id===selectedId)){selectedId=null;document.getElementById("detail").hidden=true}
}
document.addEventListener("click",e=>{if(!e.target.closest(".challenge-menu-wrap")){document.querySelectorAll(".challenge-menu.open").forEach(x=>x.classList.remove("open"));document.querySelectorAll("[data-menu][aria-expanded='true']").forEach(x=>x.setAttribute("aria-expanded","false"))}});
function current(){return state.challenges.find(c=>c.id===selectedId)}
function openChallenge(id){selectedId=id;filter="all";document.getElementById("search").value="";document.querySelectorAll(".filter").forEach(b=>b.classList.toggle("active",b.dataset.filter==="all"));render();renderDetail();document.getElementById("detail").scrollIntoView({behavior:"smooth",block:"start"})}
function renderDetail(){
 const c=current();if(!c)return;const t=totals(c);document.getElementById("detailTitle").textContent=c.name;document.getElementById("detailSubtitle").textContent=`${money(t.sum)} acumulados de ${money(t.goal)} · ${t.count} de ${t.depositCount} depósitos`;
 const q=document.getElementById("search").value.trim(),grid=document.getElementById("depositGrid");grid.innerHTML="";let shown=0;
 for(let n=1;n<=c.count;n++){const value=valueFor(c,n),key=String(n),record=c.deposits[key],isDone=!!record;
 if(filter==="done"&&!isDone||filter==="pending"&&isDone)continue;
 if(q&&!String(n).includes(q)&&!money(value).toLowerCase().includes(q.toLowerCase()))continue;
 shown++;const b=document.createElement("button");b.className="cell"+(isDone?" done":"");b.innerHTML=`<b>${n}</b><small>${money(value)}</small>`;b.setAttribute("aria-label",`Depósito ${n}, ${money(value)}${isDone?", realizado":", pendente"}`);b.onclick=()=>openDeposit(n);grid.appendChild(b)}
 if(!shown)grid.innerHTML='<div class="empty">Nenhum valor encontrado.</div>';
 const recent=Object.keys(c.deposits).map(Number).sort((a,b)=>new Date(c.deposits[b].date)-new Date(c.deposits[a].date)).slice(0,10),history=document.getElementById("history");
 history.innerHTML=recent.length?recent.map(n=>{const d=c.deposits[n],v=Number(d.value??valueFor(c,n));return `<div class="history-row"><span><b>Depósito ${n}</b><small>${new Date(d.date+"T12:00:00").toLocaleDateString("pt-BR")}${d.note?" · "+esc(d.note):""}</small></span><span class="history-value">${money(v)}</span></div>`}).join(""):'<div class="history-row"><span><b>Nenhum depósito ainda</b><small>Quando registrar um valor, ele aparecerá aqui.</small></span></div>';
}
async function openDeposit(n){const c=current();if(!c)return;selectedNumber=n;const record=c.deposits[n],value=Number(record?.value??valueFor(c,n));document.getElementById("depositModalTitle").textContent=record?"Editar depósito "+n:"Registrar depósito "+n;document.getElementById("depositModalDescription").textContent=record?"Atualize o valor, a data ou a observação deste registro.":`Você está registrando um depósito de ${money(value)}.`;document.getElementById("depositAmount").value=value.toFixed(2);document.getElementById("depositAmount").disabled=c.kind==="sequential";document.getElementById("depositDate").value=record?record.date:today();document.getElementById("depositNote").value=record?.note||"";document.getElementById("depositProof").value="";const proofStatus=document.getElementById("depositProofStatus");proofStatus.textContent=record?.proofPath?"Carregando comprovante…":"Opcional. A imagem fica privada na sua conta.";if(record?.proofPath&&supabase){const {data,error}=await supabase.storage.from("deposit-proofs").createSignedUrl(record.proofPath,300);if(!error&&data?.signedUrl){proofStatus.innerHTML='<a target="_blank" rel="noopener noreferrer" href="'+esc(data.signedUrl)+'">Abrir comprovante anexado</a> · Selecione outra imagem para substituir.'}else{proofStatus.textContent="Comprovante anexado, mas não foi possível abrir. Você pode selecionar outra imagem."}}document.getElementById("confirmDeposit").textContent=record?"Salvar alterações":"Confirmar depósito";document.getElementById("removeDeposit").style.display=record?"block":"none";document.getElementById("depositDialog").showModal()}
document.getElementById("confirmDeposit").onclick=async()=>{const c=current();if(!c)return;const amount=c.kind==="sequential"?valueFor(c,selectedNumber):Number(document.getElementById("depositAmount").value||valueFor(c,selectedNumber));if(!Number.isFinite(amount)||amount<=0){alert("Informe um valor válido.");return}const wasRecorded=!!c.deposits[selectedNumber];const previousTotal=totals(c).sum,previousCount=totals(c).count;const previousRecord=c.deposits[selectedNumber]||{};let proofPath=previousRecord.proofPath||null;const proofFile=document.getElementById("depositProof").files[0];if(proofFile){if(!cloudUser||!supabase){toast("Entre na sua conta para anexar comprovantes.");return}if(!["image/jpeg","image/png","image/webp"].includes(proofFile.type)){toast("Envie uma imagem JPG, PNG ou WebP.");return}if(proofFile.size>10*1024*1024){toast("A imagem deve ter até 10 MB.");return}const ext=(proofFile.name.split(".").pop()||"jpg").toLowerCase().replace(/[^a-z0-9]/g,"");proofPath=`${cloudUser.id}/${c.id}/${selectedNumber}-${Date.now()}.${ext}`;const {error:upErr}=await supabase.storage.from("deposit-proofs").upload(proofPath,proofFile,{upsert:true,contentType:proofFile.type});if(upErr){toast("Falha ao anexar comprovante: "+upErr.message);return}}c.deposits[selectedNumber]={date:document.getElementById("depositDate").value||today(),note:document.getElementById("depositNote").value.trim(),value:amount,proofPath};if(previousRecord.proofPath&&proofPath!==previousRecord.proofPath&&supabase){const {error:oldProofError}=await supabase.storage.from("deposit-proofs").remove([previousRecord.proofPath]);if(oldProofError)console.warn("Não foi possível remover o comprovante anterior:",oldProofError.message)}const newTotal=totals(c).sum,newCount=totals(c).count;toast("Depósito salvo!");save();recordCompetitionEventForChallenge(c.id,wasRecorded?"deposit_edited":"deposit_added");document.getElementById("depositDialog").close();render();renderDetail();renderProgress();celebrateNewAchievements(c,previousTotal,newTotal,previousCount,newCount)};
document.getElementById("removeDeposit").onclick=async()=>{const c=current();if(!c)return;if(confirm("Remover este depósito do histórico?")){const oldProof=c.deposits[selectedNumber]?.proofPath;if(oldProof&&supabase)await supabase.storage.from("deposit-proofs").remove([oldProof]);delete c.deposits[selectedNumber];save();recordCompetitionEventForChallenge(c.id,"deposit_removed");document.getElementById("depositDialog").close();render();renderDetail();renderProgress();toast("Registro removido.")}};
document.getElementById("cancelDeposit").onclick=()=>document.getElementById("depositDialog").close();
document.querySelectorAll(".filter").forEach(b=>b.onclick=()=>{filter=b.dataset.filter;document.querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x===b));renderDetail()});
document.getElementById("search").oninput=renderDetail;document.getElementById("closeDetail").onclick=()=>{selectedId=null;document.getElementById("detail").hidden=true;render();document.querySelector(".section-head").scrollIntoView({behavior:"smooth",block:"start"})};
function editChallenge(id){const c=state.challenges.find(x=>x.id===id);if(!c)return;editId=id;const is283=c.kind==="sequential";document.getElementById("challengeModalTitle").textContent=is283?"Alterar a meta do Desafio 283":"Editar desafio";document.getElementById("challengeName").value=c.name;document.getElementById("challengeName").disabled=is283;document.getElementById("challengeGoal").value=c.goal;document.getElementById("challengeGoal").step=is283?"1":"0.01";document.getElementById("challengeGoal").min=is283?"283":"1";document.getElementById("challengeCount").value=c.count;document.getElementById("challengeValues").value=c.kind==="custom"?(c.values||[]).join(", "):"";document.getElementById("challengeCount").disabled=is283;document.getElementById("challengeCountLabel").style.display=is283?"none":"block";document.getElementById("challengeValuesLabel").style.display=is283?"none":"block";document.getElementById("challengeValues").style.display=is283?"none":"block";document.getElementById("challengeValuesHint").style.display=is283?"none":"block";document.getElementById("sequentialGoalHint").textContent="Os 283 depósitos serão recalculados proporcionalmente em valores inteiros (sem centavos) para atingir exatamente essa meta. Os depósitos já registrados não serão alterados.";document.getElementById("sequentialGoalHint").style.display=is283?"block":"none";document.getElementById("challengeDialog").showModal()}
document.getElementById("newChallenge").onclick=()=>{if(!cloudUser){toast("Entre na sua conta para criar desafios.");showView("settings");return}editId=null;document.getElementById("challengeModalTitle").textContent="Criar desafio";document.getElementById("challengeForm").reset();document.getElementById("challengeName").disabled=false;document.getElementById("challengeGoal").step="0.01";document.getElementById("challengeGoal").min="1";document.getElementById("challengeValues").value="";document.getElementById("challengeCount").disabled=false;document.getElementById("challengeCountLabel").style.display="block";document.getElementById("challengeValuesLabel").style.display="block";document.getElementById("challengeValues").style.display="block";document.getElementById("challengeValuesHint").style.display="block";document.getElementById("sequentialGoalHint").style.display="none";document.getElementById("challengeDialog").showModal()};
document.getElementById("cancelChallenge").onclick=()=>document.getElementById("challengeDialog").close();
document.getElementById("challengeForm").onsubmit=e=>{e.preventDefault();if(!cloudUser){toast("Entre na sua conta para gerenciar desafios.");return}const editing=editId?state.challenges.find(x=>x.id===editId):null;const is283=!!editing&&editing.kind==="sequential";const name=is283?editing.name:document.getElementById("challengeName").value.trim(),goalInput=Number(document.getElementById("challengeGoal").value),count=Number(document.getElementById("challengeCount").value),raw=document.getElementById("challengeValues").value.trim();if(!name||goalInput<=0||count<1||count>1000)return;if(is283&&!Number.isSafeInteger(goalInput)){alert("No Desafio 283, informe a meta em reais inteiros, sem centavos.");return}
 let values=null,kind="equal",goal=goalInput;
 if(raw){values=raw.split(/[,;\s]+/).filter(Boolean).map(v=>Math.round(Number(v)*100)/100);if(values.length!==count||values.some(v=>!Number.isFinite(v)||v<=0)){alert("Informe exatamente "+count+" valores válidos, separados por vírgula.");return}kind="custom";goal=values.reduce((a,b)=>a+b,0)}
 if(editId){const c=editing;if(!c)return;if(c.kind==="sequential"){const scaled=distributeSequentialGoal(goalInput,283);if(!scaled){alert("A meta precisa ser de pelo menos R$ 283,00 para distribuir ao menos R$ 1,00 por depósito.");return}c.goal=goalInput;c.values=scaled;toast("Meta do Desafio 283 atualizada! Os 283 depósitos foram recalculados em reais inteiros.")}else{c.name=name;c.count=count;c.kind=kind;c.goal=goal;c.values=values||undefined;c.depositValue=values?undefined:Math.round(goal/count*100)/100}toast("Desafio atualizado!")}
 else{const c={id:uid(),name,goal,count,kind,values:values||undefined,depositValue:values?undefined:Math.round(goal/count*100)/100,deposits:{},createdAt:Date.now()};state.challenges.push(c);selectedId=c.id;toast("Novo desafio criado!")}
 save();document.getElementById("challengeDialog").close();render();renderProgress();if(selectedId)openChallenge(selectedId);
};
function download(data,name){const blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json"}),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
document.getElementById("backupBtn").onclick=()=>download(state,"backup-meu-desafio.json");
document.getElementById("exportOne").onclick=()=>{const c=current();if(c)download({app:"Meu Desafio",version:1,challenge:c},"backup-"+c.name.toLowerCase().replace(/[^a-z0-9]+/g,"-")+".json")};
document.getElementById("backupBtn").addEventListener("contextmenu",e=>e.preventDefault());
document.getElementById("resetOne").onclick=async()=>{const c=current();if(c&&confirm(`Apagar todos os depósitos de "${c.name}"?`)){c.deposits={};save();render();renderDetail();renderProgress();try{await syncLocalToCloud();toast("Desafio reiniciado e sincronizado.")}catch(e){setSyncMessage("A limpeza ainda não foi confirmada na nuvem: "+(e.message||"verifique sua conexão"));toast("Não foi possível confirmar a limpeza na nuvem.")}}};
document.getElementById("backupBtn").onclick=()=>download({app:"Meu Desafio",version:1,challenges:state.challenges},"backup-meu-desafio.json");
document.getElementById("importFile").onchange=async e=>{const f=e.target.files[0];if(!f)return;try{const data=JSON.parse(await f.text());if(Array.isArray(data.challenges)){if(confirm("Este backup substituirá os desafios atuais. Deseja continuar?")){state={version:1,challenges:data.challenges};save();render();renderProgress();toast("Backup restaurado.")}}else if(data.challenge){state.challenges.push(data.challenge);save();render();renderProgress();toast("Desafio importado.")}else throw Error()}catch{toast("Arquivo de backup inválido.")}e.target.value=""};
document.getElementById("backupBtn").title="Exportar backup de todos os desafios";
document.getElementById("importBtn").onclick=()=>{if(!cloudUser){toast("Entre na sua conta para restaurar um backup.");return}document.getElementById("importFile").click()};

async function loadCompetitions(){
 const list=document.getElementById("competitionList");
 if(!cloudUser||!supabase){list.innerHTML='<div class="empty">Entre na sua conta para usar competições.</div>';return}
 list.innerHTML='<div class="empty">Carregando competições…</div>';
 const {data,error}=await supabase.rpc("my_competitions");
 if(error){list.innerHTML='<div class="empty">Não foi possível carregar: '+esc(error.message)+'</div>';return}
 if(!data?.length){list.innerHTML='<div class="empty">Você ainda não participa de nenhuma competição. Crie uma ou entre com um código de convite.</div>';return}
 list.innerHTML="";
 data.forEach(c=>{const card=document.createElement("article");card.className="competition-card";
 const info=document.createElement("div");const h=document.createElement("h3");h.textContent=c.name;const p=document.createElement("p");p.textContent=(c.status==="active"?"Em andamento":"Encerrada")+" · "+c.member_count+" participantes";info.append(h,p);
 const b=document.createElement("button");b.className="secondary";b.textContent="Ver ranking";b.onclick=()=>openCompetition(c.id,c.created_by);card.append(info,b);list.append(card)});
}
async function recordCompetitionEventForChallenge(challengeId,eventType){
 if(!cloudUser||!supabase||!challengeId)return;
 try{await supabase.rpc("record_challenge_competition_event",{p_challenge_id:challengeId,p_event_type:eventType})}catch{}
}
async function loadCompetitionEvents(id){
 const box=document.getElementById("competitionEvents");box.innerHTML='<div class="empty">Carregando atividade…</div>';
 const {data,error}=await supabase.rpc("competition_event_history",{p_competition_id:id});
 if(error){box.innerHTML='<div class="empty">Histórico indisponível nesta versão do banco.</div>';return}
 if(!data?.length){box.innerHTML='<div class="empty">Nenhuma atividade registrada ainda.</div>';return}
 const labels={created:"criou a competição",joined:"entrou na competição",left:"saiu da competição",ended:"encerrou a competição",deposit_added:"registrou um novo depósito",deposit_edited:"atualizou um depósito",deposit_removed:"removeu um depósito"};
 box.innerHTML=data.map(e=>`<div class="ranking-row" style="grid-template-columns:minmax(0,1fr) auto"><div><div class="ranking-name">${esc(e.display_name||"Participante")} ${labels[e.event_type]||"realizou uma ação"}</div><div class="ranking-meta">${new Date(e.created_at).toLocaleString("pt-BR")}</div></div><span>•</span></div>`).join("");
}
async function viewMemberDeposits(competitionId,memberId,member){const box=document.getElementById("memberChallengeDialog");if(!box){const d=document.createElement("dialog");d.id="memberChallengeDialog";d.innerHTML='<div class="modal"><h3 id="memberChallengeTitle">Desafio do participante</h3><p id="memberChallengeSummary"></p><div id="memberChallengeGrid" class="grid"></div><div class="modal-actions"><button class="primary" id="closeMemberChallenge">Fechar</button></div></div>';document.body.append(d);d.querySelector('#closeMemberChallenge').onclick=()=>d.close()}const d=document.getElementById('memberChallengeDialog');document.getElementById('memberChallengeTitle').textContent=member?.display_name||'Desafio do participante';document.getElementById('memberChallengeSummary').textContent='Carregando depósitos…';document.getElementById('memberChallengeGrid').innerHTML='';d.showModal();const {data,error}=await supabase.rpc('competition_member_deposits',{p_competition_id:competitionId,p_member_id:memberId});if(error){document.getElementById('memberChallengeSummary').textContent='Não foi possível carregar: '+error.message;return}const done=(data||[]).filter(x=>x.deposited);const total=done.reduce((a,x)=>a+Number(x.deposited_amount??x.planned_amount),0);document.getElementById('memberChallengeSummary').textContent=`${done.length} depósitos realizados · ${money(total)} acumulados. Visualização somente leitura.`;document.getElementById('memberChallengeGrid').innerHTML=(data||[]).map(x=>`<div class="cell ${x.deposited?'done':''}" aria-label="Depósito ${x.slot_number}"><b>${x.slot_number}</b><small>${money(x.deposited?Number(x.deposited_amount??x.planned_amount):Number(x.planned_amount))}</small></div>`).join('')||'<div class="empty">Nenhum depósito encontrado.</div>';}
async function openCompetition(id,creator){
 if(!cloudUser)return;activeCompetitionId=id;activeCompetitionCreator=creator;
 document.getElementById("competitionDetail").hidden=false;
 const people=document.getElementById("competitionParticipantChallenges");
 people.innerHTML='<div class="empty">Carregando ranking…</div>';
 const {data,error}=await supabase.rpc("competition_ranking",{p_competition_id:id});
 if(error){people.innerHTML='<div class="empty">Erro ao carregar ranking: '+esc(error.message)+'</div>';return}
 if(!data?.length){people.innerHTML='<div class="empty">Nenhum participante encontrado.</div>';return}
 const first=data[0];document.getElementById("competitionDetailName").textContent=first.competition_name;
 document.getElementById("competitionDetailCode").textContent=first.invite_code;
 document.getElementById("competitionDetailMeta").textContent=data.length+" participantes · Ranking pelo saldo acumulado";
 document.getElementById("endCompetitionBtn").hidden=creator!==cloudUser.id;
 const {data:members,error:memberErr}=await supabase.rpc("competition_member_challenges",{p_competition_id:id});
 if(memberErr){people.innerHTML='<div class="empty">Não foi possível carregar os desafios dos participantes: '+esc(memberErr.message)+'</div>';return}
 const rankingByUser=new Map(data.map(r=>[r.user_id,r]));
 const ordered=[...(members||[])].sort((a,b)=>Number(b.total_saved||0)-Number(a.total_saved||0));
 people.innerHTML=ordered.map((m,index)=>{
  const rank=rankingByUser.get(m.user_id)?.rank_position||index+1;
  const pct=Math.max(0,Math.min(100,Number(m.progress_percent)||0));
  return `<button type="button" class="challenge" data-member="${esc(m.user_id)}" style="text-align:left;color:inherit"><div class="challenge-head"><div style="display:flex;align-items:center;gap:10px"><span class="ranking-position" aria-label="${rank}º lugar">${rank}º</span><img src="${esc(m.avatar_url||'icon-192.png')}" alt="" style="width:48px;height:48px;border-radius:50%;object-fit:cover"><div><h3>${esc(m.display_name||'Participante')}</h3><p class="desc">${esc(m.challenge_name||'Desafio 283')}</p></div></div><span class="status">Ver desafio</span></div><div class="challenge-total">${money(m.total_saved)}</div><div class="challenge-meta"><span>${m.deposit_count} depósitos</span><span>${pct.toLocaleString('pt-BR')}%</span></div><div class="track"><div class="fill" style="width:${pct}%"></div></div></button>`
 }).join('');
 people.querySelectorAll('[data-member]').forEach(btn=>btn.onclick=()=>viewMemberDeposits(id,btn.dataset.member,ordered.find(x=>x.user_id===btn.dataset.member)));
 await loadCompetitionEvents(id);
 document.getElementById("competitionDetail").scrollIntoView({behavior:"smooth",block:"start"});
}
async function createCompetition(){
 if(!cloudUser){toast("Entre na sua conta para criar uma competição.");showView("settings");return}
 const name=prompt("Qual será o nome da competição?");if(name===null)return;
 if(name.trim().length<2){toast("Use pelo menos 2 caracteres no nome.");return}
 const {data,error}=await supabase.rpc("create_competition",{p_name:name.trim()});
 if(error){toast("Não foi possível criar: "+error.message);return}
 toast("Competição criada!");await loadCompetitions();await openCompetition(data,cloudUser.id);
}
async function joinCompetition(){
 if(!cloudUser){toast("Entre na sua conta para participar.");showView("settings");return}
 const code=document.getElementById("competitionInviteCode").value.trim().toUpperCase();
 if(code.length<4){toast("Digite um código de convite válido.");return}
 const {data,error}=await supabase.rpc("join_competition",{p_invite_code:code});
 if(error){toast("Não foi possível entrar: "+error.message);return}
 document.getElementById("competitionInviteCode").value="";toast("Você entrou na competição!");await loadCompetitions();await openCompetition(data,null);
}
document.getElementById("createCompetitionBtn").onclick=createCompetition;
document.getElementById("joinCompetitionBtn").onclick=joinCompetition;
document.getElementById("closeCompetitionDetail").onclick=()=>{document.getElementById("competitionDetail").hidden=true;activeCompetitionId=null};
document.getElementById("refreshCompetitionBtn").onclick=()=>activeCompetitionId&&openCompetition(activeCompetitionId,activeCompetitionCreator);
document.getElementById("shareCompetitionBtn").onclick=async()=>{const code=document.getElementById("competitionDetailCode").textContent;const text=`Participe da minha competição no Meu Desafio! Use o código: ${code}`;try{if(navigator.share)await navigator.share({title:"Meu Desafio",text});else if(navigator.clipboard?.writeText){await navigator.clipboard.writeText(text);toast("Convite copiado!")}else prompt("Copie o convite:",text)}catch(e){if(e.name!=="AbortError")toast("Não foi possível compartilhar o convite.")}};
document.getElementById("leaveCompetitionBtn").onclick=async()=>{if(!activeCompetitionId||!confirm("Deseja sair desta competição? Seus desafios e depósitos pessoais continuarão intactos."))return;const {error}=await supabase.rpc("leave_competition",{p_competition_id:activeCompetitionId});if(error){toast(error.message);return}document.getElementById("competitionDetail").hidden=true;activeCompetitionId=null;toast("Você saiu da competição.");await loadCompetitions()};
document.getElementById("endCompetitionBtn").onclick=async()=>{if(!activeCompetitionId||!confirm("Encerrar esta competição para todos os participantes?"))return;const {error}=await supabase.rpc("end_competition",{p_competition_id:activeCompetitionId});if(error){toast(error.message);return}toast("Competição encerrada.");document.getElementById("competitionDetail").hidden=true;activeCompetitionId=null;await loadCompetitions()};

function showView(key){
 document.querySelectorAll(".app-view").forEach(v=>{const active=v.dataset.view===key;v.classList.toggle("active",active);v.hidden=!active});
 document.querySelectorAll("[data-nav]").forEach(b=>b.classList.toggle("active",b.dataset.nav===key));
 window.scrollTo({top:0,behavior:"smooth"});
 if(key==="progress")renderProgress();if(key==="achievements")renderAchievements();if(key==="competitions")loadCompetitions();
}
document.querySelectorAll("[data-nav]").forEach(btn=>btn.addEventListener("click",()=>showView(btn.dataset.nav)));
document.querySelectorAll("[data-goto]").forEach(btn=>btn.addEventListener("click",()=>showView(btn.dataset.goto)));
document.getElementById("saveProfile").onclick=async()=>{
 const display=document.getElementById("profileName").value.trim();
 if(!display){toast("Informe um nome para o perfil.");return}
 if(!cloudUser||!supabase){toast("Entre na sua conta para salvar seu nome na nuvem.");return}
 let {data:updated,error}=await supabase.from("profiles").update({display_name:display}).eq("id",cloudUser.id).select("id").maybeSingle();
 if(error){toast("Não foi possível salvar na nuvem: "+error.message);return}
 if(!updated){const result=await supabase.from("profiles").insert({id:cloudUser.id,display_name:display});if(result.error){toast("Não foi possível salvar na nuvem: "+result.error.message);return}}
 updateBrandDisplayName(display);toast("Perfil atualizado na nuvem.");
};
// Preferências visuais: inicializadas fora do fluxo de login para funcionarem também com conta conectada.
const appearanceRoot=document.documentElement;
const accentHex={green:"#087a50",blue:"#2563eb",purple:"#7c3aed",pink:"#db2777",red:"#dc2626",orange:"#ea580c",gold:"#b58a25",turquoise:"#0d9488"};
let savedTheme=localStorage.getItem("md-theme")||"dark";
let savedAccent=localStorage.getItem("md-accent")||"green";
function applyAppearance(theme=savedTheme,accent=savedAccent){
  const hex=accent.startsWith("#")?accent:(accentHex[accent]||accentHex.green);
  const dark=theme==="dark";
  const rgb=parseInt(hex.slice(1),16), rr=(rgb>>16)&255, gg=(rgb>>8)&255, bb=rgb&255;
  const mix=(a,b,t)=>Math.round(a+(b-a)*t);
  const toHex=(r,g,b)=>"#"+[r,g,b].map(v=>v.toString(16).padStart(2,"0")).join("");
  const soft=toHex(mix(rr,255,dark?.82:.90),mix(gg,255,dark?.82:.90),mix(bb,255,dark?.82:.90));
  const deep=toHex(mix(rr,0,.18),mix(gg,0,.18),mix(bb,0,.18));
  const accentText=dark?toHex(mix(rr,255,.38),mix(gg,255,.38),mix(bb,255,.38)):deep;
  appearanceRoot.dataset.theme=theme;
  appearanceRoot.dataset.accent=accent.startsWith("#")?"custom":accent;
  appearanceRoot.style.setProperty("--accent",hex);
  appearanceRoot.style.setProperty("--forest",hex);
  appearanceRoot.style.setProperty("--forest2",deep);
  appearanceRoot.style.setProperty("--accent-soft",dark?hex+"35":soft);
  appearanceRoot.style.setProperty("--accent-ink",dark?accentText:deep);
  appearanceRoot.style.setProperty("--accent-text",accentText);
  appearanceRoot.style.setProperty("--mint",dark?hex+"28":soft);
  appearanceRoot.style.setProperty("--mint2",dark?hex+"18":soft);
  appearanceRoot.style.setProperty("--bg",dark?"#111713":"#f5f7f5");
  appearanceRoot.style.setProperty("--paper",dark?"#1d2420":"#ffffff");
  appearanceRoot.style.setProperty("--ink",dark?"#e5eee9":"#18251f");
  appearanceRoot.style.setProperty("--muted",dark?"#a2b0a8":"#718078");
  appearanceRoot.style.setProperty("--line",dark?"#3b4840":"#e5ebe7");
  document.querySelectorAll(".palette-choice").forEach(b=>b.classList.toggle("selected",b.dataset.accent===accent));
  const themeControl=document.getElementById("themePreference");
  if(themeControl)themeControl.value=theme;
  const colorControl=document.getElementById("customAccentColor");
  if(colorControl)colorControl.value=hex;
  const meta=document.querySelector('meta[name="theme-color"]');
  if(meta)meta.content=dark?"#111111":"#ffffff";
}
applyAppearance();
document.getElementById("themePreference").addEventListener("change",e=>{savedTheme=e.target.value;localStorage.setItem("md-theme",savedTheme);applyAppearance();});
document.querySelectorAll(".palette-choice").forEach(b=>b.addEventListener("click",()=>{savedAccent=b.dataset.accent;localStorage.setItem("md-accent",savedAccent);applyAppearance();}));
const customAccentControl=document.getElementById("customAccentColor");if(customAccentControl)customAccentControl.addEventListener("input",e=>{savedAccent=e.target.value;localStorage.setItem("md-accent",savedAccent);applyAppearance();});
document.getElementById("resetAppearanceBtn").addEventListener("click",()=>{savedTheme="dark";savedAccent="green";localStorage.setItem("md-theme",savedTheme);localStorage.setItem("md-accent",savedAccent);applyAppearance();});
document.getElementById("changeProfilePhotoBtn").addEventListener("click",()=>{
  if(!cloudUser||!supabase){toast("Entre na sua conta para alterar a foto.");return;}
  document.getElementById("profilePhoto").click();
});

let avatarCropImage=null,avatarCropFile=null,avatarCropZoom=1,avatarCropOffsetX=0,avatarCropOffsetY=0,avatarCropPointer=null;
const avatarCropCanvas=document.getElementById("avatarCropCanvas"),avatarCropCtx=avatarCropCanvas.getContext("2d"),avatarCropModal=document.getElementById("avatarCropModal"),avatarCropZoomInput=document.getElementById("avatarCropZoom");
function drawAvatarCrop(){if(!avatarCropImage)return;const size=avatarCropCanvas.width,base=Math.max(size/avatarCropImage.width,size/avatarCropImage.height),scale=base*avatarCropZoom,w=avatarCropImage.width*scale,h=avatarCropImage.height*scale;const minX=size-w,maxX=0,minY=size-h,maxY=0;avatarCropOffsetX=Math.min(maxX,Math.max(minX,avatarCropOffsetX));avatarCropOffsetY=Math.min(maxY,Math.max(minY,avatarCropOffsetY));avatarCropCtx.clearRect(0,0,size,size);avatarCropCtx.fillStyle="#101713";avatarCropCtx.fillRect(0,0,size,size);avatarCropCtx.drawImage(avatarCropImage,avatarCropOffsetX,avatarCropOffsetY,w,h);}
function closeAvatarCrop(){avatarCropModal.hidden=true;avatarCropImage=null;avatarCropFile=null;document.getElementById("profilePhoto").value="";}
document.getElementById("profilePhoto").onchange=e=>{const file=e.target.files[0];if(!file)return;if(!cloudUser||!supabase){toast("Entre na sua conta para alterar a foto.");e.target.value="";return}if(file.size>5*1024*1024){toast("A foto deve ter até 5 MB.");e.target.value="";return}if(!["image/jpeg","image/png","image/webp"].includes(file.type)){toast("Escolha uma imagem JPG, PNG ou WebP.");e.target.value="";return}const url=URL.createObjectURL(file);const img=new Image();img.onload=()=>{avatarCropImage=img;avatarCropFile=file;avatarCropZoom=1;avatarCropZoomInput.value="1";const base=Math.max(avatarCropCanvas.width/img.width,avatarCropCanvas.height/img.height);avatarCropOffsetX=(avatarCropCanvas.width-img.width*base)/2;avatarCropOffsetY=(avatarCropCanvas.height-img.height*base)/2;drawAvatarCrop();avatarCropModal.hidden=false;URL.revokeObjectURL(url)};img.onerror=()=>{URL.revokeObjectURL(url);toast("Não foi possível abrir essa imagem.");e.target.value=""};img.src=url;};
avatarCropZoomInput.oninput=()=>{if(!avatarCropImage)return;const size=avatarCropCanvas.width,oldScale=Math.max(size/avatarCropImage.width,size/avatarCropImage.height)*avatarCropZoom,newZoom=Number(avatarCropZoomInput.value),newScale=Math.max(size/avatarCropImage.width,size/avatarCropImage.height)*newZoom,cx=size/2,cy=size/2,relX=(cx-avatarCropOffsetX)/oldScale,relY=(cy-avatarCropOffsetY)/oldScale;avatarCropZoom=newZoom;avatarCropOffsetX=cx-relX*newScale;avatarCropOffsetY=cy-relY*newScale;drawAvatarCrop()};
avatarCropCanvas.addEventListener("pointerdown",e=>{if(!avatarCropImage)return;avatarCropPointer={id:e.pointerId,x:e.clientX,y:e.clientY,ox:avatarCropOffsetX,oy:avatarCropOffsetY};avatarCropCanvas.setPointerCapture(e.pointerId)});
avatarCropCanvas.addEventListener("pointermove",e=>{if(!avatarCropPointer||avatarCropPointer.id!==e.pointerId)return;const rect=avatarCropCanvas.getBoundingClientRect(),factor=avatarCropCanvas.width/rect.width;avatarCropOffsetX=avatarCropPointer.ox+(e.clientX-avatarCropPointer.x)*factor;avatarCropOffsetY=avatarCropPointer.oy+(e.clientY-avatarCropPointer.y)*factor;drawAvatarCrop()});
["pointerup","pointercancel","lostpointercapture"].forEach(ev=>avatarCropCanvas.addEventListener(ev,()=>{avatarCropPointer=null}));
document.getElementById("cancelAvatarCrop").onclick=closeAvatarCrop;
avatarCropModal.addEventListener("click",e=>{if(e.target===avatarCropModal)closeAvatarCrop()});
document.getElementById("saveAvatarCrop").onclick=async()=>{if(!avatarCropImage||!avatarCropFile)return;const btn=document.getElementById("saveAvatarCrop");btn.disabled=true;btn.textContent="Enviando…";try{const blob=await new Promise(resolve=>avatarCropCanvas.toBlob(resolve,"image/jpeg",.9));if(!blob)throw new Error("Não foi possível preparar a imagem.");const path=`${cloudUser.id}/avatar-${Date.now()}.jpg`;const {error}=await supabase.storage.from("profile-photos").upload(path,blob,{upsert:true,contentType:"image/jpeg"});if(error)throw error;const {data}=supabase.storage.from("profile-photos").getPublicUrl(path);let {data:updated,error:profileErr}=await supabase.from("profiles").update({avatar_url:data.publicUrl}).eq("id",cloudUser.id).select("id").maybeSingle();if(profileErr)throw profileErr;if(!updated){const result=await supabase.from("profiles").insert({id:cloudUser.id,avatar_url:data.publicUrl});if(result.error)throw result.error}document.getElementById("profileAvatarPreview").src=data.publicUrl;document.getElementById("headerAvatar").src=data.publicUrl;closeAvatarCrop();toast("Foto de perfil atualizada!")}catch(error){toast("Não foi possível salvar a foto: "+(error.message||"Erro inesperado"))}finally{btn.disabled=false;btn.textContent="Usar esta foto"}};
document.getElementById("profileName").value="";

if("serviceWorker"in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredPrompt=e;document.getElementById("installBtn").hidden=false});
document.getElementById("installBtn").onclick=async()=>{if(!deferredPrompt)return;deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null;document.getElementById("installBtn").hidden=true};
render();renderProgress();
})();
