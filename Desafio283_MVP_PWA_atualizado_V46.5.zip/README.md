Meu Desafio — V46.5 (base V46.4 / reconstruída a partir da V46.2)

Correções desta versão:
- Menu de três pontos movido para o canto superior direito do card, ao lado do status (Em andamento/Pausado/Concluído).
- Botões “Abrir desafio” e “Alterar a meta” exibidos lado a lado no rodapé do card do Desafio 283.
- “Alterar a meta” permanece exclusivo do Desafio 283.
- Menu preserva Editar (somente desafios personalizados), Pausar/Retomar, Concluir/Reabrir e Excluir desafio.
- Exclusão permanece separada visualmente, em vermelho, e exige confirmação.
- Nome do Desafio 283 permanece protegido.

Mantidas as conquistas financeiras proporcionais à meta real e os demais recursos da V46.4. Não foram alterados scripts SQL, configurações do Supabase, autenticação, sincronização ou estrutura de dados nesta correção.
