Meu Desafio V9: acabamento visual, remoção dos caracteres literais \n exibidos no rodapé e atualização da versão apresentada em Ajustes. Mantém navegação, desafios, progresso, perfil local e backup.

## Versão 10 — conta e sincronização
Esta versão adiciona cadastro e login por e-mail/senha usando Supabase Auth e sincronização dos desafios com as tabelas `profiles`, `challenges` e `challenge_deposits` já criadas no projeto. A chave `sb_publishable` fica no cliente; nunca publique a chave `sb_secret`.

Antes de testar:
1. No Supabase, Authentication → URL Configuration, mantenha o Site URL e Redirect URL apontando para a URL publicada do GitHub Pages.
2. Authentication → Providers → Email deve estar habilitado.
3. Confirme o e-mail ao criar a conta, se a confirmação estiver habilitada.
4. Faça login. Se a conta ainda não tiver desafios na nuvem, os desafios locais serão enviados para ela. Se já houver desafios na nuvem, eles serão carregados no dispositivo.

A sincronização depende das políticas RLS criadas para as três tabelas.
