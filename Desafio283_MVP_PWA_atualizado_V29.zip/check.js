
(async()=>{
const SUPABASE_URL="https://gkzjwxxwxntvzarksnyt.supabase.co";
const SUPABASE_KEY="sb_publishable_is7WBxm9jMD_VMPfdylotA_yLZddIu5";
async function loadSupabaseLibrary(){
 if(window.supabase?.createClient)return true;
 for(const url of ["https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2","https://unpkg.com/@supabase/supabase-js@2"]){
  try{await new Promise((resolve,reject)=>{const script=document.createElement("script");script.src=url;script.onload=resolve;script.onerror=()=>reject(new Error("Falha ao carregar biblioteca"));document.head.appendChild(script)});if(window.supabase?.createClient)return true;}catch{}
 }
 return false;
}
// Detecta os dois formatos de retorno do Supabase antes que a sessão seja restaurada.
const recoveryHashParams=new URLSearchParams(location.hash.replace(/^#/,""));
const recoveryCode=new URLSearchParams(location.search).get("code");
let passwordRecoveryMode=Boolean(recoveryCode||recoveryHashParams.get("type")==="recovery");
const supabaseAvailable=await loadSupabaseLibrary();
const supabase=supabaseAvailable?window.supabase.createClient(SUPABASE_URL,SUPABASE_KEY):null;
let cloudUser=null, cloudBusy=false, cloudTimer=null;
const STORE="meuDesafio-v1", LEGACY="desafio283-v1";
let state=loadState(), selectedId=null, selectedNumber=1, filter="all", challengeFilter="all", editId=null, deferredPrompt=null;
const money=n=>Number(n||0).toLocaleString("pt-BR",{style:"currency",currency:"BRL"});
const today=()=>new Date().toLocaleDateString("en-CA");
const uid=()=> "d"+Date.now().toString(36)+Math.random().toString(36).slice(2,7);
function loadState(){
 try{const saved=JSON.parse(localStorage.getItem(STORE)||"null");if(saved&&Array.isArray(saved.challenges))return saved;}catch{}
 let old={};try{old=JSON.parse(localStorage.getItem(LEGACY)||"{}")}catch{}
 return {version:1,challenges:[{id:"desafio283",name:"Desafio 283",goal:40186,count:283,kind:"sequential",deposits:old&&typeof old==="object"?old:{},createdAt:Date.now()}]};
}
function save(){
 localStorage.setItem(STORE,JSON.stringify(state));
 if(cloudUser){clearTimeout(cloudTimer);cloudTimer=setTimeout(()=>syncLocalToCloud().catch(e=>setSyncMessage("Falha ao sincronizar: "+(e.message||"verifique sua conexão"))),700)}
}
function setSyncMessage(msg){const el=document.getElementById("syncStatus");if(el)el.textContent=msg}
function mapChallengeToRow(c,userId){
 return {user_id:userId,name:c.name,challenge_type:c.kind==="sequential"?"progressive":"custom",goal_amount:Number(c.goal)||0,status:c.status||"active"};
}
async function syncLocalToCloud(){
 if(!cloudUser||cloudBusy)return;cloudBusy=true;setSyncMessage("Sincronizando seus desafios...");
 try{
  const {data:remote,error:rErr}=await supabase.from("challenges").select("id").eq("user_id",cloudUser.id);
  if(rErr)throw rErr;
  const localIds=new Set(state.challenges.map(c=>c.id));
  const remoteIds=(remote||[]).map(x=>x.id);
  const removed=remoteIds.filter(id=>!localIds.has(id));
  if(removed.length){const {error}=await supabase.from("challenges").delete().in("id",removed);if(error)throw error;}
  for(const c of state.challenges){
   const row=mapChallengeToRow(c,cloudUser.id);
   let challengeId=c.id;
   const isUuid=/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(c.id));
   if(isUuid){
    const {error}=await supabase.from("challenges").upsert({...row,id:c.id},{onConflict:"id"});if(error)throw error;
   }else{
    const {data,error}=await supabase.from("challenges").insert(row).select("id").single();if(error)throw error;
    challengeId=data.id;c.id=challengeId;
   }
   const {error:delErr}=await supabase.from("challenge_deposits").delete().eq("challenge_id",challengeId);if(delErr)throw delErr;
   const slots=[];
   for(let n=1;n<=Number(c.count||0);n++){
    const d=c.deposits?.[String(n)],planned=Number(valueFor(c,n));
    slots.push({challenge_id:challengeId,user_id:cloudUser.id,slot_number:n,planned_amount:planned,deposited:!!d,deposited_amount:d?Number(d.value??planned):null,deposited_at:d?.date?new Date(d.date+"T12:00:00").toISOString():null,note:d?.note||null});
   }
   for(let i=0;i<slots.length;i+=500){const {error}=await supabase.from("challenge_deposits").insert(slots.slice(i,i+500));if(error)throw error;}
  }
  localStorage.setItem(STORE,JSON.stringify(state));setSyncMessage("Sincronizado com a nuvem.");
 }finally{cloudBusy=false}
}
async function loadCloudToLocal(){
 const {data:rows,error}=await supabase.from("challenges").select("*").eq("user_id",cloudUser.id).order("created_at",{ascending:true});if(error)throw error;
 if(!rows?.length){
  if(state.challenges?.length){await syncLocalToCloud();return}
  state={version:1,challenges:[]};save();render();return;
 }
 const ids=rows.map(r=>r.id);
 const {data:deps,error:dErr}=await supabase.from("challenge_deposits").select("*").in("challenge_id",ids).order("slot_number");if(dErr)throw dErr;
 state={version:1,challenges:rows.map(r=>{
  const ds=(deps||[]).filter(d=>d.challenge_id===r.id);
  const kind=r.challenge_type==="progressive"?"sequential":"custom";
  const values=ds.map(d=>Number(d.planned_amount));
  const c={id:r.id,name:r.name,goal:Number(r.goal_amount),count:ds.length,kind,deposits:{},status:r.status||"active",createdAt:r.created_at?new Date(r.created_at).getTime():Date.now()};
  if(kind==="custom"){c.values=values;c.depositValue=values.length&&values.every(v=>v===values[0])?values[0]:undefined}
  ds.forEach(d=>{if(d.deposited)c.deposits[String(d.slot_number)]={date:d.deposited_at?d.deposited_at.slice(0,10):today(),note:d.note||"",value:Number(d.deposited_amount??d.planned_amount)}});
  return c;
 })};
 localStorage.setItem(STORE,JSON.stringify(state));render();setSyncMessage("Dados carregados da nuvem.");
}

const onboardingSteps=[
 {icon:"◈",title:"Seu Desafio 283 já está pronto!",text:"Sua conta gratuita começa com o desafio clássico: 283 depósitos progressivos, de R$ 1 a R$ 283.",highlight:"Meta total: R$ 40.186,00 · Todos os depósitos começam pendentes.",action:"Como funciona"},
 {icon:"✓",title:"Registre cada conquista",text:"Abra o Desafio 283 e toque no número do depósito que você realizou. Informe a data e, se quiser, adicione uma observação.",highlight:"Dica: o progresso e o total economizado são atualizados conforme você registra os depósitos.",action:"Próximo"},
 {icon:"＋",title:"Crie desafios do seu jeito",text:"Além do Desafio 283, use “Novo desafio” para organizar uma viagem, uma reserva ou qualquer outro objetivo, com valores iguais ou personalizados.",highlight:"Seus desafios ficam sincronizados na nuvem e podem ser acessados em outros dispositivos.",action:"Começar a usar"}
];
let onboardingIndex=0;
function finishOnboarding(){if(cloudUser)localStorage.setItem("meuDesafio-onboarding-v1-"+cloudUser.id,"done");document.getElementById("onboarding").hidden=true;}
function showOnboarding(){if(!cloudUser)return;const key="meuDesafio-onboarding-v1-"+cloudUser.id;if(localStorage.getItem(key)==="done")return;onboardingIndex=0;renderOnboardingStep();document.getElementById("onboarding").hidden=false;}
function renderOnboardingStep(){const step=onboardingSteps[onboardingIndex];document.getElementById("onboardingIcon").textContent=step.icon;document.getElementById("onboardingTitle").textContent=step.title;document.getElementById("onboardingText").textContent=step.text;document.getElementById("onboardingHighlight").textContent=step.highlight;document.getElementById("onboardingNext").textContent=onboardingIndex===onboardingSteps.length-1?"Começar a usar":step.action;document.getElementById("onboardingBack").hidden=onboardingIndex===0;document.querySelectorAll(".onboarding-dots span").forEach((dot,i)=>dot.classList.toggle("active",i===onboardingIndex));}
document.getElementById("onboardingNext").onclick=()=>{if(onboardingIndex<onboardingSteps.length-1){onboardingIndex++;renderOnboardingStep()}else{finishOnboarding();showView("challenges")}};
document.getElementById("onboardingBack").onclick=()=>{if(onboardingIndex>0){onboardingIndex--;renderOnboardingStep()}};
document.getElementById("onboardingSkip").onclick=finishOnboarding;
document.getElementById("openTutorialBtn").onclick=()=>{onboardingIndex=0;renderOnboardingStep();document.getElementById("onboarding").hidden=false;};

async function activateSession(session){
 cloudUser=session?.user||null;
 const panel=document.getElementById("authPanel"),form=document.getElementById("authForm"),account=document.getElementById("accountPanel");
 if(!panel)return;
 if(cloudUser){
  form.hidden=true;account.hidden=false;document.getElementById("authMessage").hidden=true;
  document.getElementById("accountHeading").textContent="Sua conta está conectada";
  document.getElementById("accountDescription").textContent="Seus desafios estão vinculados à sua conta e podem ser acessados em outros dispositivos.";
  document.getElementById("accountEmail").textContent=cloudUser.email||"Conta conectada";
  setSyncMessage("Conectado. Carregando seus dados da nuvem...");
  try{
   const {data:profile,error:profileError}=await supabase.from("profiles").select("display_name").eq("id",cloudUser.id).maybeSingle();
   if(profileError)throw profileError;
   const metadataName=cloudUser.user_metadata?.full_name||cloudUser.user_metadata?.name||cloudUser.user_metadata?.display_name||"";
   const suggested=profile?.display_name||metadataName||"";
   document.getElementById("profileName").value=suggested;
   if(!profile?.display_name && metadataName){const {error}=await supabase.from("profiles").upsert({id:cloudUser.id,display_name:metadataName},{onConflict:"id"});if(error)throw error;}
   document.getElementById("profileDescription").textContent="Nome associado à sua conta e sincronizado na nuvem. Você pode alterá-lo quando quiser.";
   // Garante o desafio padrão para contas sem desafios, sem criar duplicatas.
   const {error:defaultChallengeError}=await supabase.rpc("ensure_default_challenge");
   if(defaultChallengeError)throw defaultChallengeError;
   await loadCloudToLocal();
   setTimeout(showOnboarding,500);
  }catch(e){setSyncMessage("Não foi possível sincronizar: "+(e.message||"verifique as permissões"))}
  }else{
  clearTimeout(cloudTimer);cloudTimer=null;cloudUser=null;selectedId=null;state={version:1,challenges:[]};
  document.getElementById("authEmail").value="";document.getElementById("authPassword").value="";document.getElementById("signupName").value="";document.getElementById("detail").hidden=true;
  form.hidden=false;account.hidden=true;document.getElementById("authMessage").hidden=false;document.getElementById("profileName").value="";
  document.getElementById("accountHeading").textContent="Entre na sua conta";
  document.getElementById("accountDescription").textContent="Seus desafios ficarão salvos na nuvem e poderão ser acessados em outros dispositivos.";
  document.getElementById("profileDescription").textContent="Entre na sua conta para manter seu nome sincronizado em outros dispositivos.";
  setSyncMessage("Entre ou crie uma conta para ativar a sincronização.")
 }
}
document.getElementById("togglePassword").onclick=()=>{const input=document.getElementById("authPassword"),btn=document.getElementById("togglePassword"),show=input.type==="password";input.type=show?"text":"password";btn.textContent=show?"◎":"◉";btn.setAttribute("aria-label",show?"Ocultar senha":"Mostrar senha");btn.setAttribute("aria-pressed",String(show));};
document.getElementById("authForm").addEventListener("submit",async e=>{
 e.preventDefault();const email=document.getElementById("authEmail").value.trim(),password=document.getElementById("authPassword").value;
 document.getElementById("authMessage").textContent="Entrando...";
 if(!supabase){document.getElementById("authMessage").textContent="Não foi possível carregar o serviço de acesso. Verifique sua conexão e atualize a página.";return}
 if(!supabase){document.getElementById("authMessage").textContent="Não foi possível carregar o serviço de acesso. Verifique sua conexão e atualize a página.";return}
 const {data,error}=await supabase.auth.signInWithPassword({email,password});
 if(error)document.getElementById("authMessage").textContent=error.message;else await activateSession(data.session);
});
const recoveryModal=document.getElementById("recoveryEmailModal");
function closeRecoveryModal(){recoveryModal.hidden=true;document.getElementById("recoveryModalMessage").textContent="";}
document.getElementById("forgotPasswordBtn").onclick=()=>{
 const currentEmail=document.getElementById("authEmail").value.trim();
 document.getElementById("recoveryEmail").value=currentEmail;
 document.getElementById("recoveryModalMessage").textContent="";
 recoveryModal.hidden=false;
 setTimeout(()=>document.getElementById("recoveryEmail").focus(),50);
};
document.getElementById("closeRecoveryModal").onclick=closeRecoveryModal;
document.getElementById("cancelRecovery").onclick=closeRecoveryModal;
document.getElementById("sendRecoveryEmail").onclick=async()=>{
 const email=document.getElementById("recoveryEmail").value.trim(),msg=document.getElementById("recoveryModalMessage"),btn=document.getElementById("sendRecoveryEmail");
 if(!email){msg.textContent="Informe o e-mail da sua conta.";document.getElementById("recoveryEmail").focus();return}
 if(!supabase){msg.textContent="Serviço de acesso indisponível. Verifique sua conexão.";return}
 btn.disabled=true;msg.textContent="Enviando link...";
 const {error}=await supabase.auth.resetPasswordForEmail(email,{redirectTo:location.origin+location.pathname});
 btn.disabled=false;
 msg.textContent=error?"Não foi possível enviar o link: "+error.message:"Se houver uma conta para esse e-mail, enviaremos o link de recuperação. Confira sua caixa de entrada e o spam.";
 if(!error){document.getElementById("authMessage").textContent="Solicitação enviada. Confira seu e-mail para continuar.";setTimeout(closeRecoveryModal,1800)}
};
document.getElementById("saveNewPasswordBtn").onclick=async()=>{
 const password=document.getElementById("newPassword").value,confirm=document.getElementById("confirmNewPassword").value,msg=document.getElementById("authMessage");
 if(password.length<8){msg.textContent="A nova senha precisa ter pelo menos 8 caracteres.";return}
 if(password!==confirm){msg.textContent="As senhas não coincidem. Confira e tente novamente.";return}
 const {error}=await supabase.auth.updateUser({password});
 if(error){msg.textContent="Não foi possível atualizar a senha: "+error.message;return}
 await supabase.auth.signOut();
 passwordRecoveryMode=false;cloudUser=null;selectedId=null;state={version:1,challenges:[]};
 document.getElementById("passwordRecoveryPanel").hidden=true;
 document.getElementById("authForm").hidden=false;
 document.getElementById("accountPanel").hidden=true;
 document.getElementById("authEmail").value="";
 document.getElementById("authPassword").value="";
 document.getElementById("newPassword").value="";document.getElementById("confirmNewPassword").value="";
 document.getElementById("accountHeading").textContent="Entre ou crie sua conta";
 document.getElementById("accountDescription").textContent="Acesse seus desafios em qualquer dispositivo.";
 document.getElementById("authMessage").hidden=false;
 msg.textContent="Senha atualizada! Agora entre usando sua nova senha.";
 history.replaceState({},document.title,location.pathname+"?v=22");
 render();renderProgress();
};
document.getElementById("signupBtn").onclick=async()=>{
 const email=document.getElementById("authEmail").value.trim(),password=document.getElementById("authPassword").value;
 const displayName=document.getElementById("signupName").value.trim();
 if(!displayName){document.getElementById("authMessage").textContent="Informe seu nome de exibição para criar a conta.";return}
 if(!email||password.length<8){document.getElementById("authMessage").textContent="Informe um e-mail válido e uma senha com pelo menos 8 caracteres.";return}
 if(!supabase){document.getElementById("authMessage").textContent="Não foi possível carregar o serviço de acesso. Verifique sua conexão e atualize a página.";return}
 if(!supabase){document.getElementById("authMessage").textContent="Não foi possível carregar o serviço de acesso. Verifique sua conexão e atualize a página.";return}
 document.getElementById("authMessage").textContent="Criando sua conta...";
 const {data,error}=await supabase.auth.signUp({email,password,options:{emailRedirectTo:location.href.split("#")[0],data:{full_name:displayName,name:displayName,display_name:displayName}}});
 document.getElementById("authMessage").textContent=error?error.message:(data.session?"Conta criada!": "Conta criada. Confirme seu e-mail pelo link que enviamos antes de entrar.");
 if(data.session)await activateSession(data.session);
};
document.getElementById("logoutBtn").onclick=async()=>{
 if(!supabase)return;clearTimeout(cloudTimer);cloudTimer=null;
 const {error}=await supabase.auth.signOut();if(error){setSyncMessage("Não foi possível sair: "+error.message);return}
 cloudUser=null;selectedId=null;state={version:1,challenges:[]};
 document.getElementById("authEmail").value="";document.getElementById("authPassword").value="";document.getElementById("signupName").value="";document.getElementById("detail").hidden=true;
 render();renderProgress();await activateSession(null);
};
document.getElementById("deleteAccountBtn").onclick=async()=>{
 if(!cloudUser||!supabase)return;
 const first=confirm("Excluir sua conta permanentemente? Seus desafios, depósitos e perfil na nuvem também serão apagados. Esta ação não pode ser desfeita.");
 if(!first)return;
 const second=prompt('Para confirmar, digite EXCLUIR.');
 if(second!=="EXCLUIR"){toast("Exclusão cancelada.");return}
 const btn=document.getElementById("deleteAccountBtn");btn.disabled=true;btn.textContent="Excluindo conta...";
 try{
  const {data,error}=await supabase.functions.invoke("delete-account");
  if(error)throw error;
  clearTimeout(cloudTimer);cloudTimer=null;
  await supabase.auth.signOut();
  cloudUser=null;selectedId=null;state={version:1,challenges:[]};localStorage.setItem(STORE,JSON.stringify(state));
  document.getElementById("detail").hidden=true;render();renderProgress();await activateSession(null);
  document.getElementById("authMessage").textContent="Sua conta e seus dados foram excluídos.";toast("Conta excluída com sucesso.");
 }catch(e){setSyncMessage("Não foi possível excluir a conta: "+(e.message||"erro no servidor"));}
 finally{btn.disabled=false;btn.textContent="Excluir minha conta"}
};
document.getElementById("syncNowBtn").onclick=()=>syncLocalToCloud().catch(e=>setSyncMessage("Falha: "+(e.message||"erro de sincronização")));
function showPasswordRecoveryPanel(){
 showView("settings");
 document.getElementById("passwordRecoveryPanel").hidden=false;
 document.getElementById("authForm").hidden=true;
 document.getElementById("accountPanel").hidden=true;
 document.getElementById("authMessage").hidden=false;
 document.getElementById("authMessage").textContent="Link validado. Cadastre sua nova senha abaixo.";
 document.getElementById("accountHeading").textContent="Recuperar senha";
 document.getElementById("accountDescription").textContent="Escolha uma nova senha para sua conta.";
 document.getElementById("authPanel").scrollIntoView({behavior:"smooth",block:"start"});
}
if(supabase){
 supabase.auth.onAuthStateChange((event,session)=>{
  if(event==="PASSWORD_RECOVERY")passwordRecoveryMode=true;
  setTimeout(()=>{
  if(event==="PASSWORD_RECOVERY"){
   passwordRecoveryMode=true;
   showPasswordRecoveryPanel();
   return;
  }
  if(passwordRecoveryMode)return;
  if(!session){cloudUser=null;selectedId=null;state={version:1,challenges:[]};render();renderProgress();activateSession(null)}
  else if(session.user?.id!==cloudUser?.id)activateSession(session)
 },0)});
 if(recoveryCode){
  supabase.auth.exchangeCodeForSession(recoveryCode).then(({error})=>{
   if(error){passwordRecoveryMode=false;document.getElementById("authMessage").textContent="Não foi possível validar o link de recuperação. Solicite um novo link e abra-o novamente.";return;}
   passwordRecoveryMode=true;
   history.replaceState({},document.title,location.pathname+"?v=22");
   showPasswordRecoveryPanel();
  });
 }
 supabase.auth.getSession().then(({data})=>{
  if(passwordRecoveryMode){
   if(data.session){showPasswordRecoveryPanel();history.replaceState({},document.title,location.pathname+"?v=22");}
   return;
  }
  activateSession(data.session);
 });
}else{
 document.getElementById("authMessage").textContent="Serviço de acesso indisponível no momento. Confira a internet e atualize a página.";
}

function toast(msg){const t=document.getElementById("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200)}
function valueFor(c,n){if(c.kind==="sequential")return Number(n);if(c.kind==="custom")return Number(c.values?.[n-1]||0);return Number(c.depositValue||0)}
function totals(c){const nums=Object.keys(c.deposits||{}).map(Number);const sum=nums.reduce((a,n)=>a+Number(c.deposits[n]?.value??valueFor(c,n)),0);return {count:nums.length,sum,goal:Number(c.goal)||0,depositCount:Number(c.count)||0}}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}

function renderHomeHighlights(){
 const box=document.getElementById("homeChallenges"),next=document.getElementById("homeNextDeposits");
 if(!cloudUser){box.innerHTML='<div class="empty">Entre na sua conta para visualizar seus desafios.</div>';next.innerHTML='<div class="empty">Entre na sua conta para visualizar os próximos depósitos.</div>';return}
 const all=state.challenges||[];
 const active=all.filter(c=>c.status!=="paused"&&c.status!=="completed"&&!(totals(c).goal>0&&totals(c).sum>=totals(c).goal));
 const items=active.slice(0,3);
 box.innerHTML=items.length?items.map(c=>{const t=totals(c),pct=t.goal?Math.min(100,t.sum/t.goal*100):0;return `<div class="home-mini"><span><b>${esc(c.name)}</b><small>${money(t.sum)} de ${money(t.goal)} · ${pct.toFixed(0)}%</small></span><strong>${t.count}/${t.depositCount}</strong></div>`}).join(""):'<div class="empty">Nenhum desafio em andamento no momento.</div>';
 const upcoming=active.map(c=>{const t=totals(c);let n=0;for(let i=1;i<=t.depositCount;i++){if(!c.deposits?.[i]){n=i;break}}return n?{c,n,value:valueFor(c,n)}:null}).filter(Boolean).slice(0,3);
 next.innerHTML=upcoming.length?upcoming.map(x=>`<div class="home-mini"><span><b>${esc(x.c.name)}</b><small>Próximo depósito · Nº ${x.n}</small><span class="home-next">${money(x.value)}</span></span><button class="secondary" type="button" data-home-open="${esc(x.c.id)}">Continuar</button></div>`).join(""):'<div class="empty">Você já registrou todos os depósitos dos desafios ativos. Mandou bem!</div>';
 next.querySelectorAll("[data-home-open]").forEach(b=>b.onclick=()=>{showView("challenges");openChallenge(b.dataset.homeOpen)});
}

function renderProgress(){
 if(!cloudUser){document.getElementById("progressSaved").textContent=money(0);document.getElementById("progressPercent").textContent="0,0%";document.getElementById("progressDeposits").textContent="0";document.getElementById("progressCompleted").textContent="0";document.getElementById("progressChallenges").innerHTML='<div class="empty">Entre na sua conta para visualizar seu progresso.</div>';document.getElementById("allHistory").innerHTML='<div class="empty">Entre na sua conta para visualizar seu histórico.</div>';return}
 const all=state.challenges||[];let sum=0,goals=0,deposits=0,completed=0,records=[];
 all.forEach(c=>{const t=totals(c);sum+=t.sum;goals+=t.goal;deposits+=t.count;if(c.status==="completed"||(t.goal>0&&t.sum>=t.goal))completed++;
 Object.keys(c.deposits||{}).forEach(n=>{const d=c.deposits[n];records.push({name:c.name,n:Number(n),date:d.date||"",value:Number(d.value??valueFor(c,Number(n)))})})});
 document.getElementById("progressSaved").textContent=money(sum);document.getElementById("progressPercent").textContent=(goals?Math.min(100,sum/goals*100):0).toFixed(1).replace(".",",")+"%";document.getElementById("progressDeposits").textContent=deposits;document.getElementById("progressCompleted").textContent=completed;
 document.getElementById("progressChallenges").innerHTML=all.length?all.map(c=>{const t=totals(c),pct=t.goal?Math.min(100,t.sum/t.goal*100):0;return `<div class="progress-line"><div class="progress-line-head"><span>${esc(c.name)}</span><span>${pct.toFixed(1).replace(".",",")}%</span></div><small>${money(t.sum)} de ${money(t.goal)}</small><div class="progress-track"><span style="width:${pct}%"></span></div></div>`}).join(""):'<div class="empty">Crie seu primeiro desafio para acompanhar o progresso.</div>';
 records.sort((a,b)=>String(b.date).localeCompare(String(a.date)));records=records.slice(0,12);
 document.getElementById("allHistory").innerHTML=records.length?records.map(r=>`<div class="history-row"><span><b>${esc(r.name)} · Depósito ${r.n}</b><small>${r.date?new Date(r.date+"T12:00:00").toLocaleDateString("pt-BR"):"Data não informada"}</small></span><span class="history-value">${money(r.value)}</span></div>`).join(""):'<div class="empty">Seus depósitos aparecerão aqui.</div>';
}

function render(){
 const list=document.getElementById("challengeList"),detail=document.getElementById("detail");
 if(!cloudUser){document.getElementById("totalSaved").textContent=money(0);document.getElementById("completedCount").textContent="0";document.getElementById("totalDeposits").textContent="0";document.getElementById("totalGoals").textContent=money(0);document.getElementById("remainingTotal").textContent=money(0);document.getElementById("activeCount").textContent="0 desafios ativos";document.getElementById("homePercent").textContent="0%";document.getElementById("homeProgressBar").style.width="0%";document.getElementById("homeChallenges").innerHTML='<div class="empty">Entre na sua conta para visualizar seus desafios.</div>';document.getElementById("homeNextDeposits").innerHTML='<div class="empty">Entre na sua conta para visualizar os próximos depósitos.</div>';list.innerHTML='<div class="empty">Entre na sua conta para acessar seus desafios.</div>';detail.hidden=true;selectedId=null;return}
 const all=state.challenges||[];let sum=0,goals=0,done=0,deposits=0,active=0;
 all.forEach(c=>{
  const t=totals(c);
  sum+=t.sum;goals+=t.goal;deposits+=t.count;
  const reachedGoal=t.goal>0&&t.sum>=t.goal;
  const isCompleted=c.status==="completed"||reachedGoal;
  const isPaused=c.status==="paused";
  if(isCompleted)done++;
  else if(!isPaused)active++;
 });
 document.getElementById("totalSaved").textContent=money(sum);document.getElementById("completedCount").textContent=done;document.getElementById("totalDeposits").textContent=all.reduce((a,c)=>a+totals(c).count,0);document.getElementById("totalGoals").textContent=money(goals);document.getElementById("remainingTotal").textContent=money(Math.max(0,goals-sum));document.getElementById("activeCount").textContent=active+" desafios ativos";const overallPct=goals?Math.min(100,sum/goals*100):0;document.getElementById("homePercent").textContent=overallPct.toFixed(1).replace(".",",")+"%";document.getElementById("homeProgressBar").style.width=overallPct+"%";renderHomeHighlights();
 document.getElementById("view-challenges").appendChild(detail);
 list.innerHTML="";
 if(!all.length){list.innerHTML='<div class="empty">Você ainda não criou nenhum desafio. Que tal começar agora?</div>'}
 all.forEach(c=>{const t=totals(c),pct=t.goal?Math.min(100,t.sum/t.goal*100):0,remaining=Math.max(0,t.goal-t.sum),isDone=c.status==="completed"||(t.sum>=t.goal&&t.goal>0),isPaused=c.status==="paused";
 if(challengeFilter==="active"&&(isDone||isPaused)||challengeFilter==="paused"&&!isPaused||challengeFilter==="completed"&&!isDone)return;
 const el=document.createElement("article");el.className="challenge";
 el.innerHTML=`<div class="challenge-head"><div><h3>${esc(c.name)}</h3><p class="desc">${c.kind==="sequential"?"Depósitos de valores progressivos":c.kind==="custom"?"Depósitos com valores personalizados":t.depositCount+" depósitos planejados"}</p></div><span class="status">${isDone?"Concluído":isPaused?"Pausado":"Em andamento"}</span></div><div class="challenge-total">${money(t.sum)}</div><div class="challenge-meta"><span>Meta: ${money(t.goal)}</span><span>${pct.toFixed(1).replace(".",",")}%</span></div><div class="track"><div class="fill" style="width:${pct}%"></div></div><div class="challenge-meta" style="margin-bottom:12px"><span>${t.count} depósitos feitos</span><span>Faltam ${money(remaining)}</span></div><div class="challenge-actions"><button class="primary" data-open="${c.id}">Abrir desafio</button><button class="secondary" data-edit="${c.id}">Editar</button><button class="secondary" data-toggle="${c.id}">${isPaused?"Retomar":"Pausar"}</button><button class="secondary" data-complete="${c.id}">${isDone?"Reabrir":"Concluir"}</button><button class="secondary danger" data-delete="${c.id}">Excluir</button></div>`;
 list.appendChild(el);
  if(selectedId===c.id){detail.hidden=false;el.appendChild(detail);}
 });
 list.querySelectorAll("[data-open]").forEach(b=>b.onclick=()=>openChallenge(b.dataset.open));
 list.querySelectorAll("[data-edit]").forEach(b=>b.onclick=()=>editChallenge(b.dataset.edit));
 list.querySelectorAll("[data-delete]").forEach(b=>b.onclick=()=>{const c=state.challenges.find(x=>x.id===b.dataset.delete);if(c&&confirm(`Excluir "${c.name}" e todo o histórico? Esta ação não pode ser desfeita.`)){state.challenges=state.challenges.filter(x=>x.id!==c.id);if(selectedId===c.id){selectedId=null;document.getElementById("detail").hidden=true}save();render();toast("Desafio excluído.")}});
 list.querySelectorAll("[data-toggle]").forEach(b=>b.onclick=()=>{const c=state.challenges.find(x=>x.id===b.dataset.toggle);if(!c)return;c.status=c.status==="paused"?"active":"paused";save();render();toast(c.status==="paused"?"Desafio pausado.":"Desafio retomado.")});
 list.querySelectorAll("[data-complete]").forEach(b=>b.onclick=()=>{const c=state.challenges.find(x=>x.id===b.dataset.complete);if(!c)return;c.status=c.status==="completed"?"active":"completed";save();render();toast(c.status==="completed"?"Desafio concluído.":"Desafio reaberto.")});
 if(selectedId&&!all.some(c=>c.id===selectedId)){selectedId=null;document.getElementById("detail").hidden=true}
}
function current(){return state.challenges.find(c=>c.id===selectedId)}
function openChallenge(id){selectedId=id;filter="all";document.getElementById("search").value="";document.querySelectorAll(".filter").forEach(b=>b.classList.toggle("active",b.dataset.filter==="all"));render();renderDetail();document.getElementById("detail").scrollIntoView({behavior:"smooth",block:"start"})}
function renderDetail(){
 const c=current();if(!c)return;const t=totals(c);document.getElementById("detailTitle").textContent=c.name;document.getElementById("detailSubtitle").textContent=`${money(t.sum)} acumulados de ${money(t.goal)} · ${t.count} de ${t.depositCount} depósitos`;
 const q=document.getElementById("search").value.trim(),grid=document.getElementById("depositGrid");grid.innerHTML="";let shown=0;
 for(let n=1;n<=c.count;n++){const value=valueFor(c,n),key=String(n),record=c.deposits[key],isDone=!!record;
 if(filter==="done"&&!isDone||filter==="pending"&&isDone)continue;
 if(q&&!String(n).includes(q)&&!money(value).toLowerCase().includes(q.toLowerCase()))continue;
 shown++;const b=document.createElement("button");b.className="cell"+(isDone?" done":"");b.innerHTML=`<b>${n}</b><small>${money(value)}</small>`;b.setAttribute("aria-label",`Depósito ${n}, ${money(value)}${isDone?", realizado":", pendente"}`);b.onclick=()=>openDeposit(n);grid.appendChild(b)}
 if(!shown)grid.innerHTML='<div class="empty">Nenhum valor encontrado.</div>';
 const recent=Object.keys(c.deposits).map(Number).sort((a,b)=>new Date(c.deposits[b].date)-new Date(c.deposits[a].date)).slice(0,10),history=document.getElementById("history");
 history.innerHTML=recent.length?recent.map(n=>{const d=c.deposits[n],v=Number(d.value??valueFor(c,n));return `<div class="history-row"><span><b>Depósito ${n}</b><small>${new Date(d.date+"T12:00:00").toLocaleDateString("pt-BR")}${d.note?" · "+esc(d.note):""}</small></span><span class="history-value">${money(v)}</span></div>`}).join(""):'<div class="history-row"><span><b>Nenhum depósito ainda</b><small>Quando registrar um valor, ele aparecerá aqui.</small></span></div>';
}
function openDeposit(n){const c=current();if(!c)return;selectedNumber=n;const record=c.deposits[n],value=Number(record?.value??valueFor(c,n));document.getElementById("depositModalTitle").textContent=record?"Editar depósito "+n:"Registrar depósito "+n;document.getElementById("depositModalDescription").textContent=record?"Atualize o valor, a data ou a observação deste registro.":`Você está registrando um depósito de ${money(value)}.`;document.getElementById("depositAmount").value=value.toFixed(2);document.getElementById("depositAmount").disabled=c.kind==="sequential";document.getElementById("depositDate").value=record?record.date:today();document.getElementById("depositNote").value=record?.note||"";document.getElementById("confirmDeposit").textContent=record?"Salvar alterações":"Confirmar depósito";document.getElementById("removeDeposit").style.display=record?"block":"none";document.getElementById("depositDialog").showModal()}
document.getElementById("confirmDeposit").onclick=()=>{const c=current();if(!c)return;const amount=c.kind==="sequential"?valueFor(c,selectedNumber):Number(document.getElementById("depositAmount").value||valueFor(c,selectedNumber));if(!Number.isFinite(amount)||amount<=0){alert("Informe um valor válido.");return}c.deposits[selectedNumber]={date:document.getElementById("depositDate").value||today(),note:document.getElementById("depositNote").value.trim(),value:amount};toast("Depósito salvo!");save();document.getElementById("depositDialog").close();render();renderDetail()};
document.getElementById("removeDeposit").onclick=()=>{const c=current();if(!c)return;if(confirm("Remover este depósito do histórico?")){delete c.deposits[selectedNumber];save();document.getElementById("depositDialog").close();render();renderDetail();toast("Registro removido.")}};
document.getElementById("cancelDeposit").onclick=()=>document.getElementById("depositDialog").close();
document.querySelectorAll(".filter").forEach(b=>b.onclick=()=>{filter=b.dataset.filter;document.querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x===b));renderDetail()});
document.getElementById("search").oninput=renderDetail;document.getElementById("closeDetail").onclick=()=>{selectedId=null;document.getElementById("detail").hidden=true;render();document.querySelector(".section-head").scrollIntoView({behavior:"smooth",block:"start"})};
function editChallenge(id){const c=state.challenges.find(x=>x.id===id);if(!c)return;editId=id;document.getElementById("challengeModalTitle").textContent="Editar desafio";document.getElementById("challengeName").value=c.name;document.getElementById("challengeGoal").value=c.goal;document.getElementById("challengeCount").value=c.count;document.getElementById("challengeValues").value=c.kind==="custom"?(c.values||[]).join(", "):"";document.getElementById("challengeDialog").showModal()}
document.getElementById("newChallenge").onclick=()=>{if(!cloudUser){toast("Entre na sua conta para criar desafios.");showView("settings");return}editId=null;document.getElementById("challengeModalTitle").textContent="Criar desafio";document.getElementById("challengeForm").reset();document.getElementById("challengeValues").value="";document.getElementById("challengeDialog").showModal()};
document.getElementById("cancelChallenge").onclick=()=>document.getElementById("challengeDialog").close();
document.getElementById("challengeForm").onsubmit=e=>{e.preventDefault();if(!cloudUser){toast("Entre na sua conta para gerenciar desafios.");return}const name=document.getElementById("challengeName").value.trim(),goalInput=Number(document.getElementById("challengeGoal").value),count=Number(document.getElementById("challengeCount").value),raw=document.getElementById("challengeValues").value.trim();if(!name||goalInput<=0||count<1||count>1000)return;
 let values=null,kind="equal",goal=goalInput;
 if(raw){values=raw.split(/[,;\s]+/).filter(Boolean).map(v=>Math.round(Number(v)*100)/100);if(values.length!==count||values.some(v=>!Number.isFinite(v)||v<=0)){alert("Informe exatamente "+count+" valores válidos, separados por vírgula.");return}kind="custom";goal=values.reduce((a,b)=>a+b,0)}
 if(editId){const c=state.challenges.find(x=>x.id===editId);if(!c)return;if(c.kind==="sequential"){c.name=name}else{c.name=name;c.count=count;c.kind=kind;c.goal=goal;c.values=values||undefined;c.depositValue=values?undefined:Math.round(goal/count*100)/100}toast("Desafio atualizado!")}
 else{const c={id:uid(),name,goal,count,kind,values:values||undefined,depositValue:values?undefined:Math.round(goal/count*100)/100,deposits:{},createdAt:Date.now()};state.challenges.push(c);selectedId=c.id;toast("Novo desafio criado!")}
 save();document.getElementById("challengeDialog").close();render();if(selectedId)openChallenge(selectedId);
};
function download(data,name){const blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json"}),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
document.getElementById("backupBtn").onclick=()=>download(state,"backup-meu-desafio.json");
document.getElementById("exportOne").onclick=()=>{const c=current();if(c)download({app:"Meu Desafio",version:1,challenge:c},"backup-"+c.name.toLowerCase().replace(/[^a-z0-9]+/g,"-")+".json")};
document.getElementById("backupBtn").addEventListener("contextmenu",e=>e.preventDefault());
document.getElementById("resetOne").onclick=()=>{const c=current();if(c&&confirm(`Apagar todos os depósitos de "${c.name}"?`)){c.deposits={};save();render();renderDetail();toast("Desafio reiniciado.")}};
document.getElementById("backupBtn").onclick=()=>download({app:"Meu Desafio",version:1,challenges:state.challenges},"backup-meu-desafio.json");
document.getElementById("importFile").onchange=async e=>{const f=e.target.files[0];if(!f)return;try{const data=JSON.parse(await f.text());if(Array.isArray(data.challenges)){if(confirm("Este backup substituirá os desafios atuais. Deseja continuar?")){state={version:1,challenges:data.challenges};save();render();toast("Backup restaurado.")}}else if(data.challenge){state.challenges.push(data.challenge);save();render();toast("Desafio importado.")}else throw Error()}catch{toast("Arquivo de backup inválido.")}e.target.value=""};
document.getElementById("backupBtn").title="Exportar backup de todos os desafios";
document.getElementById("importBtn").onclick=()=>{if(!cloudUser){toast("Entre na sua conta para restaurar um backup.");return}document.getElementById("importFile").click()};

function showView(key){
 document.querySelectorAll(".app-view").forEach(v=>{const active=v.dataset.view===key;v.classList.toggle("active",active);v.hidden=!active});
 document.querySelectorAll("[data-nav]").forEach(b=>b.classList.toggle("active",b.dataset.nav===key));
 window.scrollTo({top:0,behavior:"smooth"});
 if(key==="progress")renderProgress();
}
document.querySelectorAll("[data-nav]").forEach(btn=>btn.addEventListener("click",()=>showView(btn.dataset.nav)));
document.querySelectorAll("[data-goto]").forEach(btn=>btn.addEventListener("click",()=>showView(btn.dataset.goto)));
document.getElementById("saveProfile").onclick=async()=>{
 const display=document.getElementById("profileName").value.trim();
 if(!display){toast("Informe um nome para o perfil.");return}
 if(!cloudUser||!supabase){toast("Entre na sua conta para salvar seu nome na nuvem.");return}
 const {error}=await supabase.from("profiles").upsert({id:cloudUser.id,display_name:display},{onConflict:"id"});
 if(error){toast("Não foi possível salvar na nuvem: "+error.message);return}
 toast("Perfil atualizado na nuvem.");
};
document.getElementById("profileName").value="";

if("serviceWorker"in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredPrompt=e;document.getElementById("installBtn").hidden=false});
document.getElementById("installBtn").onclick=async()=>{if(!deferredPrompt)return;deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null;document.getElementById("installBtn").hidden=true};
render();renderProgress();
})();
