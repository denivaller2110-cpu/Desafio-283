Meu Desafio — V45.3

Atualização global do tema: cartões, textos de destaque, ícones, estados e barras de progresso passam a respeitar a cor de destaque escolhida. Mantém o tema escuro/claro e as funcionalidades anteriores.
