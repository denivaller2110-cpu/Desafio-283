# Desafio 283 — MVP PWA

## Como testar
Abra `index.html` em um navegador para testar a interface. O salvamento local funciona no navegador.

## Como instalar como PWA
Para instalação e funcionamento offline, publique estes arquivos em uma hospedagem HTTPS (por exemplo, GitHub Pages, Netlify ou Vercel). Depois abra o endereço no Chrome/Android e use “Instalar app” ou “Adicionar à tela inicial”.

## O que já funciona
- Grade com os depósitos de R$ 1 a R$ 283.
- Marcar e desfazer depósitos.
- Data e observação opcional.
- Total economizado, saldo restante e percentual.
- Filtros, busca e histórico recente.
- Exportação e importação de backup JSON.
- Manifest e service worker para instalação/cache PWA.

## Limitação desta versão
Os dados ficam no armazenamento local do navegador/dispositivo. Não há login nem sincronização entre aparelhos ou usuários. Isso será uma próxima etapa, antes de disponibilizar uma versão multiusuário pública.
