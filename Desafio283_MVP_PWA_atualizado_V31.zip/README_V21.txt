MEU DESAFIO V21

1) SQL: execute Meu_Desafio_V21_SQL_Desafio_Padrao.sql no SQL Editor. Ele cria a RPC ensure_default_challenge, chamada pelo app quando a conta autentica. Não altera contas com desafios existentes.
2) Edge Function: publique a pasta delete-account como função Supabase chamada delete-account. Configure secrets SUPABASE_URL, SUPABASE_ANON_KEY e SUPABASE_SERVICE_ROLE_KEY no ambiente da função. A service role NUNCA deve ir para o HTML/app.
3) O botão de exclusão só funcionará depois que a Edge Function estiver implantada.
4) Atualize o GitHub Pages com os arquivos do ZIP, mantendo o processo habitual de publicação.
