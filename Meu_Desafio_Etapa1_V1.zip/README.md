# Meu Desafio — versão 1

PWA mobile-first para organizar desafios financeiros pessoais.

## Recursos
- Painel geral com totais de todos os desafios
- Desafio 283 pré-carregado
- Criação e edição de desafios personalizados
- Registro e remoção de depósitos com data e observação
- Histórico por desafio
- Backup completo e backup individual
- Importação de backup
- Armazenamento local no dispositivo

## Publicação
O conteúdo deste ZIP pode ser extraído para a pasta `public` pelo workflow GitHub Actions já utilizado no projeto.

## Atenção
Esta versão mantém dados no armazenamento local do navegador/aplicativo. Ainda não possui cadastro, login ou sincronização em nuvem.
