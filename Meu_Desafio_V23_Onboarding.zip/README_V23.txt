MEU DESAFIO V23 - ONBOARDING

Inclui uma apresentação de boas-vindas em três etapas, exibida uma única vez por conta neste navegador após o carregamento dos dados da nuvem. Explica o Desafio 283, como registrar depósitos e como criar desafios personalizados.

Mantém os recursos da V22: autenticação, sincronização, recuperação de senha, criação automática do Desafio 283 e exclusão segura via Edge Function delete-account.

PUBLICAÇÃO: remova o ZIP antigo do repositório GitHub, envie este pacote e renomeie para Desafio283_MVP_PWA_atualizado.zip. Aguarde o GitHub Actions concluir.
