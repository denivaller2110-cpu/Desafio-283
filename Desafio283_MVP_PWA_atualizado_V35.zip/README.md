Meu Desafio — V12

Atualizações:
- Área de conta identifica claramente quando o usuário está conectado.
- Nome do perfil é carregado dos metadados da conta Supabase quando disponível; caso não exista, sugere a parte do e-mail antes do @.
- Nome de exibição é armazenado na tabela public.profiles e sincronizado entre dispositivos.
- Usuário pode editar o nome e salvar na nuvem.
- Cache do PWA atualizado para V12.

Publicação: extraia os arquivos deste ZIP para a pasta public usada pelo workflow do GitHub Pages.
Mantenha a configuração Supabase existente. Nunca inclua chaves secret/service_role no frontend.

V24: adiciona Central de ajuda e tutoriais ao final da tela Ajustes. O botão reabre o tutorial de boas-vindas sem alterar o status de conclusão do onboarding.


V29: adiciona sistema de conquistas por desafio com seis marcos de depósitos (R$ 100, R$ 500, R$ 1.000, R$ 5.000, R$ 10.000 e R$ 20.000), vitrine geral no painel Progresso, indicadores de avanço e comemoração animada ao desbloquear medalhas. As conquistas são calculadas diretamente a partir dos depósitos, sem tabela adicional: permanecem consistentes entre dispositivos, sincronização Supabase e backups, e são recalculadas automaticamente quando depósitos são editados, removidos ou restaurados.


## V30
- Organiza a área de Conquistas em cartões expansíveis por desafio.
- Filtros de categoria ficam dentro do desafio expandido.
- Atualiza cache para V30.


## V35
- Corrige a atualização de nome e foto do perfil para preservar o outro campo existente.
- Permite abrir comprovantes privados por link temporário autenticado.
- Valida o tipo MIME de comprovantes e remove o arquivo anterior ao substituí-lo (quando permitido).
- Melhora a associação de fotos no ranking, priorizando o identificador do participante e usando a ordem como fallback.
- Atualiza o cache do PWA para V35.

Validação realizada: sintaxe JavaScript e integridade do pacote. Integração real com Supabase e teste entre duas contas ainda exigem execução autenticada no ambiente do usuário.
