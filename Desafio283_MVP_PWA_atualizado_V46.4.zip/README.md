Meu Desafio — V46.4 (base V46.2)

- Cards de desafios reorganizados: “Abrir desafio” permanece sempre visível; “Alterar a meta” permanece sempre visível somente no Desafio 283.
- Menu de três pontos no canto superior esquerdo de cada card.
- Menu: Editar (somente desafios personalizados), Pausar/Retomar, Concluir/Reabrir e Excluir desafio.
- Exclusão separada visualmente, em vermelho, com confirmação antes de executar.
- Nome do Desafio 283 continua protegido contra alteração.
- Conquistas financeiras calculadas pelos percentuais da meta real de cada desafio: 1%, 2,5%, 5%, 10%, 20%, 30%, 50%, 65%, 80%, 90% e 100%.
- Mantidas as conquistas por quantidade de depósitos e jornada, além das funcionalidades existentes da V46.2.

A V46.4 foi reconstruída a partir do pacote V46.2. Não foram alterados os scripts SQL, configurações do Supabase, autenticação, sincronização ou estrutura de dados.
