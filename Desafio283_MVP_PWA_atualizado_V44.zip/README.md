# Meu Desafio — V37

## Correção crítica de sincronização e recuperação estrutural

- A sincronização não exclui mais desafios remotos ausentes do estado local.
- A sincronização não apaga mais todos os depósitos para recriá-los.
- Depósitos confirmados que existem na nuvem são preservados quando o estado local está incompleto.
- Novos depósitos/slots são inseridos sem substituir os registros existentes.
- Ao carregar um desafio progressivo com slots ausentes, o app recria apenas os slots inexistentes (1 a 283), mantendo os depósitos existentes.
- Uma conta sem desafios na nuvem não recebe automaticamente dados locais possivelmente pertencentes a outra conta.

## Validação executada

- `node --check` no JavaScript inline: aprovado.
- Manifest JSON: válido.
- A integração real com Supabase precisa ser validada após a publicação de teste.

## Publicação

Remova o ZIP anterior da raiz do repositório antes de enviar este arquivo, conforme o workflow atual.
