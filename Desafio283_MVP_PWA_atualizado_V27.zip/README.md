Meu Desafio — V12

Atualizações:
- Área de conta identifica claramente quando o usuário está conectado.
- Nome do perfil é carregado dos metadados da conta Supabase quando disponível; caso não exista, sugere a parte do e-mail antes do @.
- Nome de exibição é armazenado na tabela public.profiles e sincronizado entre dispositivos.
- Usuário pode editar o nome e salvar na nuvem.
- Cache do PWA atualizado para V12.

Publicação: extraia os arquivos deste ZIP para a pasta public usada pelo workflow do GitHub Pages.
Mantenha a configuração Supabase existente. Nunca inclua chaves secret/service_role no frontend.

V24: adiciona Central de ajuda e tutoriais ao final da tela Ajustes. O botão reabre o tutorial de boas-vindas sem alterar o status de conclusão do onboarding.
