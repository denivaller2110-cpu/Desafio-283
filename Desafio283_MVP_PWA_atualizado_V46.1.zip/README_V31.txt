MEU DESAFIO — VERSÃO 31.0

Novidades:
- Nova área Competir na navegação inferior.
- Criar competição com o Desafio 283 da conta.
- Entrar em competição por código.
- Compartilhar convite.
- Ranking por saldo acumulado, com empates na mesma posição.
- Exibir quantidade de depósitos e percentual da meta.
- Sair da competição sem apagar desafios ou depósitos pessoais.
- Criador pode encerrar a competição.
- Histórico interno de eventos do grupo, sem expor datas, observações ou valores individuais.

IMPORTANTE — BANCO DE DADOS:
O SQL principal V31 já foi executado no Supabase.
Antes de publicar este ZIP, execute também o arquivo Meu_Desafio_V31_SQL_Complementar.sql no SQL Editor.

Publicação GitHub Pages:
1. Exclua o ZIP antigo da raiz do repositório.
2. Envie este ZIP para a raiz do repositório.
3. Aguarde o GitHub Actions ficar verde.
4. Abra https://denivaller2110-cpu.github.io/Desafio-283/?v=31

A V30 permanece preservada como versão publicada até a validação da V31.
