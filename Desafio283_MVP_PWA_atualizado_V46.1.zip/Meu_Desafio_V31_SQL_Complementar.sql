-- Meu Desafio V31 | Complemento do histórico interno das competições
-- Execute depois do SQL principal V31.

alter table public.competition_events
  drop constraint if exists competition_events_event_type_check;

alter table public.competition_events
  add constraint competition_events_event_type_check
  check (event_type in (
    'created','joined','left','ended',
    'deposit_added','deposit_edited','deposit_removed'
  ));

create or replace function public.record_challenge_competition_event(
  p_challenge_id uuid,
  p_event_type text
)
returns void
language plpgsql
security definer
set search_path=public,auth
as $$
declare
  v_uid uuid:=auth.uid();
begin
  if v_uid is null then raise exception 'Sessão não autenticada.'; end if;
  if p_event_type not in ('deposit_added','deposit_edited','deposit_removed') then
    raise exception 'Tipo de evento inválido.';
  end if;

  insert into public.competition_events(competition_id,actor_id,event_type)
  select m.competition_id,v_uid,p_event_type
  from public.competition_members m
  join public.competitions c on c.id=m.competition_id and c.status='active'
  where m.challenge_id=p_challenge_id and m.user_id=v_uid;
end
$$;

create or replace function public.competition_event_history(p_competition_id uuid)
returns table(
  event_type text,
  display_name text,
  created_at timestamptz
)
language sql
stable
security definer
set search_path=public,auth
as $$
  select e.event_type,
    coalesce(nullif(trim(p.display_name),''),split_part(u.email,'@',1),'Participante') as display_name,
    e.created_at
  from public.competition_events e
  left join public.profiles p on p.id=e.actor_id
  left join auth.users u on u.id=e.actor_id
  where e.competition_id=p_competition_id
    and exists(
      select 1 from public.competition_members m
      where m.competition_id=p_competition_id and m.user_id=auth.uid()
    )
  order by e.created_at desc
  limit 50;
$$;

revoke all on function public.record_challenge_competition_event(uuid,text) from public,anon;
revoke all on function public.competition_event_history(uuid) from public,anon;
grant execute on function public.record_challenge_competition_event(uuid,text) to authenticated;
grant execute on function public.competition_event_history(uuid) to authenticated;

-- Fim do complemento V31.
