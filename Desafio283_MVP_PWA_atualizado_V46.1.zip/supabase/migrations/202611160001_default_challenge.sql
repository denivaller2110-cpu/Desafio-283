-- Meu Desafio V21: desafio padrão automático para novas contas e contas sem desafios.
-- Execute este script no Supabase SQL Editor do projeto Meu Desafio.

create or replace function public.create_default_challenge_for_user(p_user_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_challenge_id uuid;
begin
  -- Não substitui nem duplica desafios de contas que já possuem dados.
  if exists (select 1 from public.challenges where user_id = p_user_id) then
    return;
  end if;

  insert into public.challenges (user_id, name, challenge_type, goal_amount, status)
  values (p_user_id, 'Desafio 283', 'progressive', 40186.00, 'active')
  returning id into v_challenge_id;

  insert into public.challenge_deposits
    (challenge_id, user_id, slot_number, planned_amount, deposited)
  select v_challenge_id, p_user_id, n, n::numeric(12,2), false
  from generate_series(1, 283) as n;
end;
$$;

revoke all on function public.create_default_challenge_for_user(uuid) from public, anon, authenticated;

create or replace function public.handle_new_user_default_challenge()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  perform public.create_default_challenge_for_user(new.id);
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_default_challenge on auth.users;
create trigger on_auth_user_created_default_challenge
after insert on auth.users
for each row execute procedure public.handle_new_user_default_challenge();

-- Backfill seguro: adiciona o Desafio 283 somente a contas que ainda não possuem
-- nenhum desafio. Contas com desafios existentes permanecem intocadas.
do $$
declare
  u record;
begin
  for u in select id from auth.users
           where not exists (select 1 from public.challenges c where c.user_id = auth.users.id)
  loop
    perform public.create_default_challenge_for_user(u.id);
  end loop;
end;
$$;
