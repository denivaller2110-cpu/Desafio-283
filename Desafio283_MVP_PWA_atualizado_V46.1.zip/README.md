Meu Desafio — V46.0

- Desafio 283: ao alterar a meta, os 283 depósitos passam a aceitar somente valores em reais inteiros, sem centavos.
- Distribuição proporcional aos pesos originais de 1 a 283.
- A primeira casinha é arredondada para cima; os demais arredondamentos são distribuídos pelas maiores frações.
- A soma dos 283 depósitos fecha exatamente a meta definida, desde que a meta seja um valor inteiro em reais e de pelo menos R$ 283,00.
- Mantidos nome, quantidade de depósitos e registros já realizados.
