-- Meu Desafio V21: cria o Desafio 283 para usuários autenticados sem desafios.
-- Não altera o fluxo de cadastro/confirmacão de e-mail e não cria duplicatas.

create or replace function public.ensure_default_challenge()
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_challenge_id uuid;
begin
  if v_user_id is null then
    raise exception 'Sessão não autenticada.';
  end if;

  -- Serializa chamadas simultâneas do mesmo usuário.
  perform pg_advisory_xact_lock(hashtextextended(v_user_id::text, 0));

  -- Se já existe qualquer desafio, preserva integralmente os dados atuais.
  if exists (select 1 from public.challenges where user_id = v_user_id) then
    return;
  end if;

  insert into public.challenges
    (user_id, name, challenge_type, goal_amount, status)
  values
    (v_user_id, 'Desafio 283', 'progressive', 40186.00, 'active')
  returning id into v_challenge_id;

  insert into public.challenge_deposits
    (challenge_id, user_id, slot_number, planned_amount, deposited)
  select v_challenge_id, v_user_id, n, n::numeric(12,2), false
  from generate_series(1, 283) as n;
end;
$$;

revoke all on function public.ensure_default_challenge() from public, anon;
grant execute on function public.ensure_default_challenge() to authenticated;
