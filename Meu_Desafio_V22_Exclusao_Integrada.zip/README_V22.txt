MEU DESAFIO V22

Inclui o botão de exclusão em Ajustes e a chamada autenticada à Edge Function delete-account. Também mantém a chamada RPC ensure_default_challenge após autenticação.

IMPORTANTE - BACKEND
A função delete-account já foi implantada no painel Supabase. Para atualizar o código com CORS completo, abra Edge Functions > delete-account > Code, substitua index.ts pelo arquivo delete-account/index.ts deste pacote e faça Deploy novamente. Mantenha Verify JWT with legacy secret DESLIGADO, pois a função valida o usuário com auth.getUser(token).

A função usa as variáveis de ambiente SUPABASE_URL, SUPABASE_ANON_KEY e SUPABASE_SERVICE_ROLE_KEY do ambiente Supabase. Não coloque service role no HTML nem compartilhe essa chave.

A exclusão remove o usuário autenticado via Admin API. As tabelas profiles, challenges e challenge_deposits devem manter suas FKs com ON DELETE CASCADE para apagar os dados associados.

PUBLICAÇÃO
Substitua o ZIP anterior no repositório pelo conteúdo deste ZIP, mantendo o nome Desafio283_MVP_PWA_atualizado.zip conforme o fluxo habitual.
