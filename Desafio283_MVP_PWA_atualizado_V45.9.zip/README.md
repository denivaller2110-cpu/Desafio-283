Meu Desafio — V45.9

- No Desafio 283, o botão “Editar” foi substituído por “Alterar a meta”.
- A ação de alterar a meta não permite alterar o nome do desafio.
- O nome e a quantidade de 283 depósitos são preservados; somente a meta e os valores planejados são recalculados.
- Nos demais desafios, a edição continua disponível normalmente.
