Meu Desafio — V45.8

Novidade: meta personalizável para o Desafio 283. Ao editar o Desafio 283, o usuário pode definir uma nova meta mantendo os 283 depósitos. Os valores são redistribuídos proporcionalmente aos pesos originais (1 a 283), em centavos, com método dos maiores restos para garantir que a soma seja exatamente a meta informada. Depósitos já registrados e seus comprovantes são preservados; somente os valores planejados são recalculados.

Atualização: cache do Service Worker V45.8.
